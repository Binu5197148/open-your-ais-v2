---
name: gauntlet-loop
description: Transforma qualquer pedido em um prompt no formato Gauntlet Loop, a técnica do Matt Shumer em que o agente monta um time de sub-agentes executores, cada um com um sub-agente verificador severo, e roda em loop até TODOS os verificadores ficarem impressionados. Use quando o usuário pedir "prompt gauntlet", "gauntlet loop", "monta o prompt nesse formato", "quero um prompt com sub-agentes e verificação", "prompt de loop até ficar perfeito", ou quando ele descrever um projeto complexo (jogo, app, site, sistema, campanha, pipeline) e quiser resultado nível excepcional em vez de "funcional". Também dispara em "faz isso com verificação de verdade" e "quero que teste como usuário final".
allowed-tools: Read, Write, Edit, Bash, AskUserQuestion, WebSearch
---

# Gauntlet Loop

Gera prompts que produzem resultado excepcional em vez de resultado funcional.

A diferença entre um projeto que "funciona" e um que impressiona não está no modelo: está na
**arquitetura de verificação** que você monta dentro do prompt. Esta skill escreve essa arquitetura.

## Os três níveis (contexto)

| Nível | Como funciona | Resultado |
|---|---|---|
| 1. Padrão | Humano pede, agente faz, **humano verifica** | Você vira o revisor. Cansa e escapa erro. |
| 2. Avançado | Agente faz, **outro agente verifica** antes de entregar | Recomendado pela Anthropic. Bom. |
| 3. **Gauntlet Loop** | **Time de agentes faz, time de agentes verifica**, em loop, até todos aprovarem | Excepcional. É o alvo desta skill. |

No nível 3 o agente principal vira técnico de futebol: escala o time, define quem joga cada posição,
coloca um auxiliar em cima de cada jogador, e só entrega o relatório quando o diretor aprova.

## Os três pilares (a estrutura obrigatória)

Todo prompt gerado por esta skill tem exatamente três blocos, nesta ordem:

### Pilar 1: A TAREFA (o quê)
O resultado desejado, com **nível de qualidade nomeado** e **referência concreta de comparação**.
Nunca "faça um jogo". Sempre "faça um FPS no nível do Call of Duty mais recente, qualidade AAA,
das texturas à física".
A referência é o que dá ao verificador uma régua objetiva depois.

### Pilar 2: A METODOLOGIA (como)
Quebrar o projeto em partes, uma sub-agente por parte, **e um verificador separado por executor**.
Elementos obrigatórios deste bloco:
- `Fan out sub-agents`: paralelizar, não fazer em fila
- uma lista explícita das frentes (física, visual, áudio, performance, UX...)
- para cada frente: um executor **e** um verificador independente
- o verificador precisa ser **crítico severo** ("really harsh critic"), não torcedor
- `/loop` em cada item: se não passar, volta e refaz

### Pilar 3: O CRITÉRIO DE PARADA (quando terminou)
O golpe de mestre da técnica. Não é "até funcionar", é:
> não pare até cada verificador estar **impressionado** (utterly wowed) com a qualidade,
> comparando lado a lado com a referência real e dizendo qual ficou melhor.

Alternativa mensurável quando o subjetivo não serve: **nota de 0 a 100, só aceita acima de 85**.
Sempre feche com o loop explícito: `/loop until it's utterly perfect`.

## O prompt original (referência canônica)

Matt Shumer, palavra por palavra, o que gerou o FPS que viralizou:

```
I want you to build a first-person shooter at the level of the most recent Call of Duty
games. It should be utterly perfect, visually beautiful, with every single thing done at
AAA quality, from textures to physics to anything you could think of.

Fan out sub-agents and have sub-agents tackle each one individually so that the game is
utterly perfect. You should /loop on each item and have a separate sub-agent check it
visually to ensure it looks triple A. That separate sub-agent should be a really harsh
critic, and if it doesn't look triple A, it should keep going.

Don't stop until each sub-agent is utterly wowed with the quality when compared with the
actual Call of Duty game. It should literally compare them side by side and say which one
looks better. Do this in ThreeJS. /loop until it's utterly perfect. Fan out sub-agents and
ultracode.
```

Note o que ele faz e quase ninguém copia: **manda comparar lado a lado com o produto real e
declarar qual ficou melhor**. Isso transforma opinião vaga em julgamento.

## As quatro melhorias que separam o prompt bom do prompt que entrega

Vieram da prática de quem rodou a técnica por horas. Aplique sempre que couber:

### 1. Verificação REAL, não revisão de código
Um verificador que só lê o código aprova coisa quebrada. O verificador precisa **usar o produto
como usuário final**: abrir o navegador, clicar nos botões, jogar o jogo, testar os comandos.
Quando o alvo for web ou app, instrua explicitamente o uso do **Playwright MCP** (ou equivalente)
e, se a ferramenta não estiver instalada, mande **instalar antes de verificar**.
Esta é a diferença entre "o código parece certo" e "eu testei e funciona".

### 2. Julgamento às cegas
O verificador não deve conhecer o contexto de como aquilo foi construído. Quem cozinha acha a
própria comida boa; quem chega no restaurante julga o prato. Instrua: o verificador recebe apenas
o resultado e os critérios, nunca o histórico de tentativas.

### 3. Teto de rodadas e de custo
O loop é infinito por natureza e isso queima tempo e tokens. Sempre defina:
- número máximo de rodadas (3 a 8 costuma ser o útil; 3 rodadas já levaram 4 horas em projeto pesado)
- orçamento de tokens quando fizer sentido (Karpathy fez o Senhor dos Anéis em 3D com teto de
  1 milhão de tokens, cerca de 10 dólares, 2 horas, 5.400 linhas)

### 4. Paralelismo de verdade (graph engineering)
Dez entregas em fila é dez vezes o tempo. Quando as partes forem independentes, instrua execução
**em paralelo** e só depois a consolidação. Fan out não é enfeite: é o que torna a técnica viável.

## Como esta skill trabalha

1. **Colete três coisas** do usuário (pergunte só o que faltar, uma pergunta por vez):
   - o que ele quer construir, e **com o que isso deve se comparar** (a referência)
   - quais frentes os sub-agentes devem atacar primeiro
   - o critério de parada: "impressionado" ou nota mínima
2. **Monte o prompt** nos três pilares, incorporando as quatro melhorias que couberem.
3. **Escreva em inglês por padrão** (os modelos respondem melhor e o original é em inglês),
   a menos que ele peça em português.
4. **Entregue o prompt em bloco de código**, pronto para colar, sem comentário no meio.
5. Diga em uma linha quantas rodadas e qual ordem de custo esperar.

## Template de saída

```
[PILAR 1, TASK]
I want you to build <o quê> at the level of <referência concreta>. It should be utterly
perfect, <qualidades específicas>, with every single thing done at <nível nomeado> quality,
from <detalhe> to <detalhe> to anything you could think of.

[PILAR 2, METHODOLOGY]
Fan out sub-agents and have each one tackle a separate area: <frente 1>, <frente 2>,
<frente 3>, <frente 4>. Run them in parallel, not in sequence. /loop on each item and have a
separate sub-agent verify it, one verifier per executor. Each verifier must be a really harsh
critic and must judge blind: give it only the result and the criteria, never the history of
attempts. Verification is not code review: the verifier must use the product as an end user
would <abrir o navegador / jogar / clicar nos fluxos>. Use Playwright MCP for that, and if it
is not installed, install it before verifying. If it does not meet the bar, keep going.

[PILAR 3, STOP CRITERION]
Don't stop until every verifier is utterly wowed with the quality compared with <referência>.
Each verifier should literally compare them side by side and say which one is better
<ou: score the result 0 to 100 and only accept above 85>. Cap this at <N> rounds
<e budget de tokens se aplicável>. /loop until it's utterly perfect. Fan out sub-agents and
ultracode.
```

## Adaptações por domínio

A técnica não é só para código. O que muda é a referência e o que o verificador testa:

- **Vídeo / filme**: referência = uma peça comercial real; verificador assiste o render e compara
  plano a plano (nitidez, deriva de cenário, continuidade, tipografia). Frentes: roteiro, still,
  animação, som, legenda, montagem.
- **Site / landing**: referência = um site do mesmo mercado que ele admira; verificador navega com
  Playwright, testa cada botão, mede carregamento, confere mobile.
- **Campanha / conteúdo**: referência = a peça que performou melhor; verificador julga gancho,
  clareza e CTA contra ela, e dá nota.
- **Documento / estratégia**: referência = um documento profissional do setor; verificador procura
  furo lógico, dado sem fonte e promessa sem evidência.

## Regras da casa

- Zero mentira: se o prompt pedir dado factual, o verificador confere em 2 fontes independentes.
- Sem travessão longo e sem hashtag em qualquer texto público gerado.
- Human First: a técnica multiplica o autor, não substitui pessoas. O critério de qualidade é dele.
