# gauntlet-loop

Turns any request into a prompt that builds a team of executor sub-agents, gives each one a harsh independent verifier, and loops until every verifier is impressed.

From the working skill library of Ulisses Balbino. Released at
https://openyourais.com/skills/

Instructions are written in: Portuguese

## Install

```
# Claude Code, available in every project
unzip gauntlet-loop.zip -d ~/.claude/skills/

# or scoped to one repo
unzip gauntlet-loop.zip -d .claude/skills/
```

You should end up with `gauntlet-loop/SKILL.md`. Start a new session so the
skill is picked up.

## Needs

Nothing to install. The verifier step works better with a browser automation MCP so the checker uses the product instead of reading the code.

## What changed before release

The owner's name was replaced with "the user" in three places. Nothing else.

## Credit

The technique is Matt Shumer's. His original prompt is reproduced inside SKILL.md word for word as the canonical reference. What is added on top: the four corrections (real verification, blind judging, round and cost caps, true parallelism) and the table that carries the technique into video, sites, campaigns and documents.

---

Shared as is, no warranty. It names third party tools and models, and
those age fast. Check what a job costs before you let an agent spend.
