# Método ElevenLabs (inspiração: vídeo oficial "How to Dub Videos into 29 Languages")

Fonte: ElevenLabs (YouTube `RKzp4OfCgBA`, 5:50). Método **manual** que inspirou esta skill.
A skill `/dublagem` automatiza a parte de gerar o áudio dublado usando o **Higgsfield**
(que ainda faz lip-sync). Este doc registra o fluxo manual do ElevenLabs como alternativa
e para a parte de **publicação multi-idioma no YouTube** (fora do escopo "só dublar", mas
útil como referência futura).

## Fluxo do vídeo

1. **Dub your content** (app do ElevenLabs):
   - Nome do projeto.
   - **Source Language** (ex.: English) → **Target Languages** (multi-seleção:
     Spanish, Portuguese, Hindi, French, German, ...).
   - **Fonte**: Upload / YouTube / TikTok / Other URL / Manual.
   - Opções: **Create Dubbing project** (deixa editável depois), "Reduce character
     usage by 33%", **Number of speakers** (Detect ou especificar, melhora qualidade),
     **Time range to dub**, **Disable voice cloning** (por padrão **clona** a voz).
   - Mostra estimativa de **créditos** → **Create dub**.
2. ElevenLabs transcreve → traduz → gera áudio dublado com voz clonada, alinhado no tempo.
3. **Download** dos vídeos dublados.

## Publicação multi-idioma no YouTube (faixas de áudio)

Fora do escopo da skill, mas é o que o vídeo mostra no final:

1. Extraia o **áudio** do vídeo dublado (Premiere Pro ou ferramenta online → `.mp3`).
2. YouTube Studio → abra o vídeo → **Languages** → **Add language** → escolha o idioma.
3. Em **Audio**, **add as "dub"** → **Select File** → escolha o `.mp3` dublado → **Publish**.
4. Traduza **título e descrição** (ex.: com ChatGPT) e **Update**.
5. O espectador troca a faixa pela engrenagem ⚙️ → **Audio track** → idioma.
6. Repita por idioma e por vídeo.

## Diferença prática vs. a skill

| | ElevenLabs (manual) | `/dublagem` (Higgsfield, automatizado) |
|---|---|---|
| Voz | Clonada | Clonada |
| Lip-sync | Não (só troca áudio) | **Sim** |
| Operação | App web, manual | Chamadas MCP no Claude Code |
| Saída | Vídeo/áudio dublado | Vídeo dublado por idioma em `human-output/dublagem/` |
