# dublagem

Dubs a video into any number of languages with the ElevenLabs Dubbing v2 REST API, one job per language, cloning the original voice and confirming the credit cost before it spends.

From the working skill library of Ulisses Balbino. Released at
https://openyourais.com/skills/

Instructions are written in: Portuguese

## Install

```
# Claude Code, available in every project
unzip dublagem.zip -d ~/.claude/skills/

# or scoped to one repo
unzip dublagem.zip -d .claude/skills/
```

You should end up with `dublagem/SKILL.md`. Start a new session so the
skill is picked up.

## Needs

An ElevenLabs API key, read from the environment or from a config file, never written into the skill. curl. yt-dlp if the source is a URL.

## What changed before release

Nothing. The file already read the key from the environment.

## Credit

MIT, declared in the skill's own frontmatter.

---

Shared as is, no warranty. It names third party tools and models, and
those age fast. Check what a job costs before you let an agent spend.
