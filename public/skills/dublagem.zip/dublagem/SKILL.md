---
name: dublagem
description: Dubla filmes e vídeos para outro idioma usando o ElevenLabs Dubbing v2 (clona a voz original, preserva emoção e sincroniza, 90+ idiomas) via API REST. Aceita arquivos locais (.mp4/.mov/.mkv/.webm/.mp3) e URLs (YouTube/TikTok/link direto). Motor alternativo opcional: Higgsfield (lip-sync no vídeo). Use quando o usuário pedir para dublar, traduzir a fala, localizar ou "fazer a dublagem" de um filme/vídeo/clipe para um ou mais idiomas. Não fixa idioma padrão, pergunta os idiomas-alvo a cada execução. Conversa em português.
argument-hint: "<arquivo-ou-url> [idiomas-alvo] [--motor elevenlabs|higgsfield]"
allowed-tools: Bash, Read, AskUserQuestion, ToolSearch
license: MIT
---

# /dublagem: dublar filmes e vídeos com ElevenLabs Dubbing v2

Pega um vídeo (arquivo local ou URL) e, para **cada idioma-alvo**, gera uma versão
**dublada** com o **ElevenLabs Dubbing v2**: ele transcreve, traduz, **clona a voz
original**, preserva emoção/entrega e **sincroniza**, em 90+ idiomas. É a função
"Dubbing" do app ElevenLabs (a do Dubbing v2 Alpha), chamada pela **API REST**.

Motor **alternativo** (opcional, `--motor higgsfield`): dubbing do Higgsfield, que
ainda faz **lip-sync** no vídeo. Use só se o usuário pedir e houver crédito Higgsfield.

## Quando usar

- "dubla esse filme pro inglês", "faz a dublagem disso em PT e ES", "traduz a fala desse vídeo".
- Entrada: arquivo no Mac (`.mp4/.mov/.mkv/.webm/.mp3`) **ou** URL (YouTube/TikTok/link direto).
- Escopo: **só dublar**, gerar o(s) arquivo(s) dublado(s). Não publica em lugar nenhum.

---

## Passo 0: Chave da API ElevenLabs (uma vez)

O Dubbing v2 é chamado pela API REST e precisa de uma **API key do ElevenLabs**
(`xi-api-key`). Procure nesta ordem e use a primeira que existir:

1. variável de ambiente `ELEVENLABS_API_KEY`;
2. arquivo `~/.config/elevenlabs/.env` (linha `ELEVENLABS_API_KEY=...`);
3. arquivo `~/.config/dublagem/.env`.

```bash
# carregar a chave
KEY="${ELEVENLABS_API_KEY:-$(grep -h '^ELEVENLABS_API_KEY=' ~/.config/elevenlabs/.env ~/.config/dublagem/.env 2>/dev/null | head -1 | cut -d= -f2-)}"
```

Se não houver chave, **pare e peça a chave ao usuário** (pegue em
elevenlabs.io → Settings → API Keys). Grave em `~/.config/elevenlabs/.env` com `chmod 600`.

## Passo 1: Parsear entrada e idiomas

1. Separe a **fonte** (arquivo ou URL) dos **idiomas-alvo**.
2. **Sem idioma padrão.** Se não vier, **pergunte** (`AskUserQuestion`, multiselect) os
   idiomas. Converta para **ISO 639-1** (`pt` português, `en` inglês, `es` espanhol,
   `fr` francês, `de` alemão, `it` italiano, `ja` japonês, `zh` chinês, etc.).
3. Defina um `run_slug` (nome do projeto + data) para a pasta de saída
   `human-output/dublagem/{run_slug}/`.

## Passo 2: Preparar a fonte

- **Arquivo local**: use o caminho direto (enviado como `file`).
- **URL de página** (YouTube/TikTok): o mais confiável é baixar antes com `yt-dlp` e
  enviar como `file` (o `source_url` da API nem sempre aceita YouTube):
  ```bash
  yt-dlp -f mp4 -o "human-output/dublagem/{run_slug}/fonte.%(ext)s" "<URL>"
  # trecho (recomendado p/ vídeo longo):
  yt-dlp -f mp4 --download-sections "*00:00:30-00:01:30" -o "human-output/dublagem/{run_slug}/fonte.%(ext)s" "<URL>"
  ```
- **Link direto** de mídia: pode usar `source_url=<URL>` em vez de `file`.

## Passo 3: CONFIRMAR custo e esperar OK (obrigatório)

Dublagem **gasta créditos ElevenLabs** (cobra por minuto de mídia × nº de idiomas).
Diga ao usuário a duração da fonte e quantos idiomas, e **espere OK explícito** antes de
disparar qualquer job. Nunca duble idioma que o usuário não pediu.

## Passo 4: Criar o(s) job(s) de dublagem (1 por idioma)

`POST https://api.elevenlabs.io/v1/dubbing` (multipart). `target_lang` é **um por job** →
faça um job por idioma. Por padrão **clona a voz** (`disable_voice_cloning=false`).

```bash
# arquivo local
curl -s -X POST https://api.elevenlabs.io/v1/dubbing \
  -H "xi-api-key: $KEY" \
  -F "file=@human-output/dublagem/{run_slug}/fonte.mp4" \
  -F "target_lang=pt" \
  -F "source_lang=auto" \
  -F "num_speakers=0" \
  -F "name={run_slug}-pt"
# → {"dubbing_id":"...","expected_duration_sec":...}

# (alternativa) a partir de URL direta:
#   -F "source_url=https://.../video.mp4"   (no lugar do -F file=@...)
```

Parâmetros úteis: `dubbing_studio=true` (deixa editável no Dubbing Studio depois),
`disable_voice_cloning=true` (usa voz parecida da biblioteca em vez de clonar),
`drop_background_audio=true`, `num_speakers=N` (0 = detecta). Guarde cada `dubbing_id`
com seu idioma.

## Passo 5: Aguardar até `dubbed`

`GET https://api.elevenlabs.io/v1/dubbing/{dubbing_id}` retorna `status` (`dubbing` →
`dubbed`; `failed` traz `error`). Faça polling espaçado (alguns segundos), não em loop apertado.

```bash
curl -s https://api.elevenlabs.io/v1/dubbing/$DUB_ID -H "xi-api-key: $KEY"
```

## Passo 6: Baixar o resultado

`GET https://api.elevenlabs.io/v1/dubbing/{dubbing_id}/audio/{language_code}` →
MP4 ou MP3 (octet-stream).

```bash
curl -s "https://api.elevenlabs.io/v1/dubbing/$DUB_ID/audio/pt" \
  -H "xi-api-key: $KEY" -o "human-output/dublagem/{run_slug}/dub_pt.mp4"
```

(Se o job foi editado no Dubbing Studio, use o endpoint de render do resource em vez deste.)

## Passo final: Entregar

1. Pasta da run: `human-output/dublagem/{run_slug}/`.
2. Um arquivo por idioma: `dub_<idioma>.mp4` (e `.mp3` se pedirem só áudio).
3. `metadados.json`: motor, fonte, idiomas, `dubbing_id`s, duração, créditos antes/depois.
4. **Relatório final**: informe a **pasta final** em link clicável e liste os arquivos
   gerados (não-`.md`) em links clicáveis.

---

## Motor alternativo: Higgsfield (`--motor higgsfield`)

Só se o usuário pedir e houver crédito. Faz **lip-sync** no vídeo. Localize via
`ToolSearch("dubbing media_upload media_confirm balance")`: confira `balance` →
**confirme custo** → resolva a fonte em `video_id` (`media_upload`→`media_confirm`, ou
`media_import_url` p/ URL ≤50MB) → `dubbing({params:{video_id, target_language}})`
(códigos: `eng por spa fra deu ita cmn hin jpn kor rus tur ara pol ind fil swe fin`) →
acompanhe com `job_display` → baixe.

## Limites e regras

- **Filme inteiro**: cobra por minuto; trabalhe por cena/segmento se for longo e avise o usuário.
- **1 idioma por job** (ElevenLabs e Higgsfield) → multi-idioma = vários jobs.
- **Sempre confirme o custo antes** e espere OK. Faça **só** o que foi pedido, não
  adicione idiomas, edições, legendas ou publicação por conta própria.
- Fale com o usuário em **português**. Cada run em `human-output/dublagem/{run_slug}/`.
- Referência do método/UX do app: `reference/metodo-elevenlabs.md`.
