---
name: roteiros-virais
description: Generate high-retention YouTube long-form scripts (8-15min) using the proven "4 blockers + 5 hooks + 7 structures" framework. Works for any niche, storytelling, true crime, mythology, curiosities, history, science, education, listicles. Produces complete shot-by-shot scripts with timestamps, voiceover lines, image prompts (NanoBanana/Midjourney), on-screen captions, retention triggers every 90s, titles, thumbnail concepts, YouTube description with hashtags, and mandatory disclaimers. Use whenever the user asks to write a YouTube script, make a video about a topic, create episodes, write voiceover narration, plan a faceless video, or wants a story-driven video script that converts. Triggers: "roteiro", "script", "vídeo de 10 minutos", "episódio", "narração", "faceless", "viral", "história sobre", "youtube long-form".
---

# Skill: Viral YouTube Scripts (Long-Form)

A complete framework for writing 8-15 minute YouTube scripts that convert, based on the "4 blockers + 5 hooks + 7 winning story structures" methodology proven across niches. Works for any topic where the deliverable is a narrated long-form video with imagery (faceless, documentary-style, listicles, explainers, storytelling).

---

## When to use this skill

Trigger this skill whenever the user asks to:
- Write a YouTube script ("roteiro", "script")
- Make a video about a topic ("faz um vídeo sobre...", "video about...")
- Plan an episode of a series
- Write narration for a faceless channel
- Create a long-form story-driven video (8min+)
- Write a script that "keeps people watching" / "high retention"

**Do NOT use** for: shorts under 60s (different framework), tutorial-only screencasts, talking-head vlogs without storytelling, written articles.

---

## Required briefing (ask these 4 if not provided)

Before writing, confirm with user:

1. **Topic / case / story**: what's the video about, in one paragraph?
2. **Target duration**: 8min, 10min, 12min, 15min? (default: 12min if unsure)
3. **Niche / channel style**: true crime, mythology, history, science, curiosities, listicle, motivational, explainer? This sets tone, hook style, and structure.
4. **Language**: PT-BR, EN-US, ES-LATAM? (impacts pacing and word count)

If user gives clear input, skip and write directly.

---

## The 4 Blockers: destroy these BEFORE writing

A blank-page script always fails on one of these. Address each explicitly:

1. **Interestingness blocker**: *Why would anyone care about this?* If you can't articulate a specific angle no other video has, you don't have a video yet. Refine the angle.
2. **Hook blocker**: *What sells the first 3 seconds?* No generic intro. The hook is a SPECIFIC visual + a SPECIFIC sentence. If hook is weak, the whole video underperforms.
3. **Storytelling blocker**: *Does each scene CREATE the next?* Lists of facts kill retention. Cause→effect chains keep viewers. Every scene must answer: "and then what?"
4. **Engagement blocker**: *Where does the viewer drop off?* Default drop zones are 1min, 4min, 8min. You need a retention trigger every 90s.

---

## Hooks: pick ONE for the video (never combine)

### A. Personal Stake Hook
*"In 1973, five people went on a picnic. Only the camera came back."*
Best for: storytelling, true crime, mystery.

### B. Problem Hook
*"For 47 years, no one could explain ONE detail in this case. And once you see it, you'll understand why."*
Best for: case studies, science explainers.

### C. Counter-intuitive Hook
*"The police closed the case in 1981. But in 2019, a declassified file contradicted everything."*
Best for: history, true crime, conspiracy with documentation.

### D. Visual Reveal Hook
*[shows photo] "Look closely at this image. There's something three different experts only spotted in 2008."*
Best for: artifact-based stories, photo analysis.

### E. Statistic Hook
*"There are 627 people who disappeared inside US national parks. This is the only one who came back."*
Best for: listicles, data-driven, top-X format.

**Rule:** the hook must contain ONE concrete, verifiable specificity (a year, a number, a name, an object). Vague hooks fail.

---

## The 7 Winning Story Structures

| Structure | When to use | Recommended duration | Default niche |
|-----------|-------------|----------------------|---------------|
| **Breakdown** | Complex case with multiple evidence pieces | 12-15min | True crime, science, geopolitics |
| **Newscaster** | Recent event, factual recounting | 8-10min | News, current events, journalism |
| **Case Study Explainer** | Resolved case with a twist | 10-12min | Business, history, biography |
| **Listicle** | "X things about Y" | 10-15min | Curiosities, top-X, shorts compilations |
| **Problem Solver** | Mystery + new theory | 10-12min | Science, research, investigative |
| **Tutorial** | "How X is done" | 8-10min | Education, behind-the-scenes |
| **Educational** | Historical / contextual deep-dive | 12-15min | History, mythology, biography |

When in doubt, **mix Breakdown + Educational**, the most versatile combo for storytelling.

---

## Mandatory script outline (use this template)

```
[00:00 - 00:15] PRIMARY HOOK
- 1 baited sentence + 1 shocking image
- No logo, no animated intro, no "what's up guys"
- Ends with implicit question

[00:15 - 00:45] SECONDARY HOOK
- "But what no one ever told you was..."
- Adds NEW info (does NOT repeat hook 1)
- Promises the "twist" that comes around minute 11

[00:45 - 02:30] CONTEXT
- Setting (place + time)
- Characters (max 4 named, group the rest)
- Status quo before the event

[02:30 - 06:00] THE EVENT
- Hour-by-hour chronology
- Cliffhanger at minute 4: "And here is where everything began to fall apart."

[06:00 - 09:00] THE INVESTIGATION / EXPLANATION
- What was found / what happened next
- Physical / documented evidence
- Cliffhanger at minute 7.5: "But one piece of evidence was hidden from the public for 20 years."

[09:00 - 11:30] THEORIES / INTERPRETATIONS
- 3-4 weighted explanations (mark speculation as such)
- For each: who proposed + why it makes sense + why it doesn't

[11:30 - 12:30] THE TWIST / LESSER-KNOWN FACT
- A late-act revelation
- "In 2019, a local resident handed over..."

[12:30 - 13:30] OPEN ENDING
- Direct question to the audience: "What do you think happened?"
- "Comment below."

[13:30 - 14:00] CTA + NEXT VIDEO TEASE
- "Subscribe, every night, a new case."
- "Next: [1-sentence teaser]."
```

Adjust durations proportionally if target is 8min or 15min, keep the segment ratios the same.

---

## Retention triggers (mandatory phrases every ~90s)

Sprinkle throughout the script (translate to user's language):
- "But the most disturbing detail comes now."
- "Here's where the story gets strange."
- "And this is where the official version begins to fail."
- "If you're confused, it'll make sense in a minute."
- "Remember this name. It comes back at the end of the video."

These are not optional, they're documented retention boosters from analyzed top-performing channels.

---

## Image prompt rules (for NanoBanana / Midjourney / Flux per scene)

For every scene, include:
- **Aspect ratio:** 16:9 (1920x1080) for main video, 9:16 for shorts
- **Style anchor:** "cinematic, desaturated, photographic realism, warm tungsten + cool moonlight, film grain, 35mm", keep CONSTANT across all scenes for visual consistency
- **Max 8s per image** (apply Ken Burns zoom/pan in editor, Remotion, DaVinci, CapCut)
- **Vary framing:** wide → close → detail → different wide
- **NEVER bake text into images**: text goes as overlay in editor
- **Faces:** blurred or back-turned (legal protection + doc-noir style)

---

## Title + thumbnail rules

Generate **5 title candidates** for every script. Pattern:
- One neutral/SEO-friendly (works long-term)
- One sensationalist (high CTR, A/B testing)
- One question-based ("What happened to...?")
- One number-based ("47 years of mystery")
- One contrarian ("The case the police got wrong")

Generate **3 thumbnail concepts**:
- Concept A (recommended): face/object close-up + bold word + diagonal red banner
- Concept B: alternative angle (different focal subject)
- Concept C: conceptual (silhouette / symbol-based)

Each thumb concept must be reproducible as an AI image prompt (write it in the output).

---

## YouTube description format (always include)

```
[ATTENTION-GRABBING SUMMARY, 3-5 lines that complete the hook]

⏱️ TIMESTAMPS
00:00, [section 1]
00:45, [section 2]
... (mirror the script outline)

📚 SOURCES
- [Source 1, must be public/verifiable]
- [Source 2]
- [Source 3]

⚠️ DISCLAIMERS (when applicable, see below)

🔔 [Subscribe + posting cadence]

#hashtag1 #hashtag2 ... (10-15 relevant tags, mix big + niche)
```

---

## Mandatory disclaimers

Add a final "Disclaimer" scene (5s, on-screen text + voice optional) when the niche is:
- **True crime / unresolved cases** → "Reconstructions based on public records and journalistic coverage. AI-generated images. No accusations are made against named individuals."
- **Conspiracy / paranormal** → "This video presents documented theories. It does not claim them as fact."
- **Health / medical** → "Educational content. Not medical advice. Consult a professional."
- **Financial / investing** → "Educational content. Not financial advice."
- **AI-generated faceless content** → "Images are artistic representations generated by AI."

Skipping these = legal risk + YouTube strikes. Non-negotiable.

---

## Output structure (always produce all 6 sections)

When invoked, produce:

### 1. Topic & angle
- Chosen topic (one paragraph)
- 3 possible angles → pick the strongest with justification
- Why this angle has retention potential

### 2. Hook selection
- 5 hook variations (from the 5 types A-E above)
- Recommend the strongest with reasoning

### 3. Structure & full script
- Chosen structure (one of the 7) with justification
- Complete timestamped script: 20-30 scenes
- For each scene: image prompt + voiceover line + on-screen caption (if any) + Ken Burns mode hint
- Retention triggers placed at correct intervals

### 4. Titles & thumbnails
- 5 title candidates with A/B testing rationale
- 3 thumbnail concepts with reproducible prompts

### 5. YouTube description
- Full copy ready to paste
- 10-15 hashtags
- Timestamps mirroring the script

### 6. Production summary
- Total duration in seconds
- Number of scenes
- Estimated AI image generation cost (NanoBanana ~$0.03/img, Midjourney ~$0.08/img)
- Estimated TTS cost (ElevenLabs Multilingual v2 ~$0.30/1k chars)
- Estimated total per video

---

## Checklist before finalizing (verify all 8)

- [ ] Hook contains ONE specific verifiable detail (year, number, name, object)
- [ ] Secondary hook adds NEW info, does not repeat hook 1
- [ ] Each scene creates the next (cause→effect, not list)
- [ ] Retention triggers placed every 90s
- [ ] No more than 4 named characters
- [ ] No scene exceeds 45s of single-image dwell
- [ ] Open ending with direct question to audience
- [ ] CTA + next video tease at end
- [ ] Disclaimer included if niche requires it
- [ ] Sources are public and verifiable

If any unchecked, revise before delivering to user.

---

## Variations by niche (quick presets)

### True crime / unresolved
- Default structure: Breakdown + Educational
- Default hook: B (Problem) or C (Counter-intuitive)
- Tone: investigative, sober, journalistic. Forbidden words: "you won't believe", "shocking" in caps, sensationalist exclamations.

### Mythology / folklore
- Default structure: Educational + Case Study Explainer
- Default hook: D (Visual Reveal) or A (Personal Stake)
- Tone: respectful, immersive. Use the original culture's terminology.

### Curiosities / historical facts
- Default structure: Listicle or Educational
- Default hook: E (Statistic)
- Tone: conversational, accessible. Cite at least one academic source per claim.

### Science / research
- Default structure: Problem Solver or Tutorial
- Default hook: B (Problem) or C (Counter-intuitive)
- Tone: precise. Distinguish "consensus" from "hypothesis" explicitly.

### Listicle / top-X
- Default structure: Listicle
- Default hook: E (Statistic)
- Pacing: each item 60-90s max. Save the strongest item for #1 (revealed last).

---

## Banned patterns (auto-reject if user requests these)

- ❌ "You won't believe what happens next" / "the result will shock you"
- ❌ Generic intros: "What's up guys, welcome back to the channel"
- ❌ Reading the title in the first 5 seconds (kills curiosity gap)
- ❌ Putting the channel logo before the hook
- ❌ More than 4 named characters in a 12min video (confuses audience)
- ❌ Single image dwelling over 45s (retention nuke)
- ❌ Speculation presented as fact (legal + ethical risk)

---

## Notes on language adaptation

When writing in PT-BR or ES-LATAM:
- Slightly slower pacing than EN (~10% more words for same duration in EN, NOT vice versa, Romance languages take more chars)
- Avoid Anglo idioms ("at the end of the day", "long story short"), translate to native equivalents
- Use formal narrator register for true crime / history; conversational for curiosities / listicles
- Voice-over speed for ElevenLabs: 0.95x for PT-BR (slightly slower = gravitas), 1.0x for EN

---

## Example invocation flow

User: "Write me a 12-minute video about the Voynich Manuscript"

1. Identify niche: history + mystery → mix Breakdown + Educational
2. Confirm angle: pick "the cryptographer who almost solved it but went insane"
3. Generate 5 hooks → recommend C (Counter-intuitive)
4. Write 22-scene script with timestamps, image prompts, captions, retention triggers
5. Generate 5 titles + 3 thumb concepts
6. Generate YouTube description with timestamps + sources + hashtags
7. Production summary: 22 scenes × $0.03 = $0.66 imagery, ~12k chars TTS = $3.60, total ~$4.30

Deliver all 6 sections. Done.
