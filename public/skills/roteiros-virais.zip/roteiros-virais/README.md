# roteiros-virais

A long-form YouTube script framework: four blockers to clear before writing, five hook types, seven story structures, and a shot-by-shot output with timestamps and image prompts.

From the working skill library of Ulisses Balbino. Released at
https://openyourais.com/skills/

Instructions are written in: English

## Install

```
# Claude Code, available in every project
unzip roteiros-virais.zip -d ~/.claude/skills/

# or scoped to one repo
unzip roteiros-virais.zip -d .claude/skills/
```

You should end up with `roteiros-virais/SKILL.md`. Start a new session so the
skill is picked up.

## Needs

Nothing. The output is text.

## What changed before release

Nothing.

---

Shared as is, no warranty. It names third party tools and models, and
those age fast. Check what a job costs before you let an agent spend.
