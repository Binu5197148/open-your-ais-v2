---
name: vox-skill
description: Produção completa no estilo Vox explainer (documentary paper collage) para QUALQUER marca, vídeos explicativos animados (stills gpt_image_2 + animação gemini_omni + edição Hyperframes/Premiere), carrosséis e single posts (clássico engraved ou futurista newsprint). Inclui anatomia de prompts validada, style-blocks travados, sistema de badge/watermark PIL, alinhamento de locução por beats e catálogo de lições aprendidas. Use para - vídeo Vox, explainer documental, paper collage, diorama de papel, carrossel Vox, carrossel futurista, post editorial minimalista, animar telas no Omni, "estilo daquele vídeo da Vox". Triggers - vox, explainer, paper collage, diorama, newsprint, /vox.
---

# VOX-STUDIO: Fábrica de conteúdo estilo Vox explainer

Skill destilada de uma produção real completa (filme 60s + 3 carrosséis + série de posts),
com os erros já pagos e as soluções validadas. **Idioma com o usuário: português.**
Stack padrão: **Higgsfield CLI** (gpt_image_2 para stills, gemini_omni para animação),
**PIL** para toda tipografia de precisão, **Hyperframes** para montagem, **ffmpeg** para
áudio/cor, **whisper-cli** para alinhamento de VO. Adapte o stack se o projeto usar outro.

## Princípio-mestre (aprendido apanhando)

1. **Sempre dissecar uma referência real primeiro.** O modelo gera a "média estatística"
   se criar do zero; o usuário é o diretor criativo e a referência é a lei. Frame a frame
   se preciso (claudetube/frames). Nunca inventar estética de cabeça.
2. **Style-block travado, repetido VERBATIM em todo prompt.** O estilo não se descreve de
   novo a cada prompt, se escreve uma vez, perfeito, e se cola inteiro sempre.
3. **Conceito literal em peça estática.** Metáfora que precisa de legenda é metáfora
   errada: em carrossel/post a imagem TEM que ser a explicação ("entender em 1 segundo").
   Metáfora abstrata só funciona em VÍDEO, onde a locução explica.
4. **Coreografia exata no prompt de animação.** "Precisa colocar exatamente o que vai
   acontecer pra IA não ter que adivinhar", segundo a segundo, elemento a elemento.
5. **Todo texto crítico é PIL com fonte real (.ttf), nunca gerado por IA** quando o
   pipeline permitir (posts clean). Quando o texto É da estética (stencil carimbado),
   gerar via modelo COM spelling guard soletrado e conferir letra por letra.
6. **Aprovação textual do usuário antes de queimar crédito.** Sempre. Conceitos + copy
   primeiro, geração depois.

## Onboarding de marca (fazer 1x por projeto novo)

Antes de produzir para uma marca nova, coletar e registrar num `BRAND.md` do projeto:
- **Cor de acento única** (o "cobalto" daquela marca) + cores proibidas.
- **Logo oficial** (PNG com alpha real) e **fonte oficial** (.ttf), paths locais.
- **Asset de produto hero** (foto oficial), o modelo NUNCA inventa o produto; a foto
  vai como `--image` de referência em todo prompt que mostre o produto.
- **Allowlist de claims e números** (o que PODE ser dito/escrito) + termos que devem
  aparecer completos + regras de compliance do setor.
- **Regra de escopo de claim**: se o benefício vale só num caso (ex: só numa modalidade),
  TODA copy E TODA metáfora visual carregam o escopo. Objeto que implica "benefício em
  tudo" é propaganda enganosa mesmo com sub correto.
- **Diversidade**: pessoas/mãos em qualquer imagem = etnias e gêneros diversos,
  explícito no prompt (o default do modelo é homem branco de terno).

## Os 3 produtos da skill

### A. VÍDEO EXPLAINER (30-90s)
Pipeline completo em [references/video-pipeline.md](references/video-pipeline.md).
Resumo: referência dissecada → roteiro + VO + trilha (aprovar) → stills por tela
(gpt_image_2, style-block travado) → animação tela a tela (gemini_omni, anatomia de
prompt + item-refs) → montagem (Hyperframes ou Premiere) → cor BT.709 → áudio (VO
alinhado por beats, trilha com fade, SFX). Prompts: [references/prompt-anatomy.md](references/prompt-anatomy.md).

### B. CARROSSEL (4:5, 5-8 cards)
Pipeline em [references/carousel-pipeline.md](references/carousel-pipeline.md).
Resumo: definir style-block (novo por refs OU um dos dois catalogados) → copy dos cards
+ QC factual/tom (aprovar) → geração sequencial 3:4 → crop 4:5 → badge/watermark PIL →
QC visual letra a letra → INDEX.md com prompts e créditos.

### C. SINGLE POSTS CLEAN (híbrido foto + PIL)
Também em [references/carousel-pipeline.md](references/carousel-pipeline.md) (seção Clean).
Resumo: Camada 1 = cena fotorreal minimalista SEM TEXTO (negative agressivo) →
Camada 2 = PIL com fonte oficial real + logo + produto. Sacada conceitual por post,
conceito literal, teste "entendeu em 1 segundo".

## Style-blocks catalogados

Em [references/style-blocks.md](references/style-blocks.md):
1. **Vox clássico engraved**: 19th-century etchings, mapa antigo, crosshatch, scraps.
2. **Vox futurista newsprint**: diorama de papel + lente cinema, newsprint bokeh,
   cutouts P&B, objetos 3D chunky de papel, stencil em labels rasgados. (o preferido
   pra extrair "vídeos mais legais", os cards viram storyboards de clipes)
3. **Como criar um style-block novo a partir de refs** (processo completo).

## Lições aprendidas (ler antes de produzir)

[references/lessons.md](references/lessons.md), o catálogo de erros pagos: typos do
modelo, logos inventados, cores fora da marca, conceito abstrato reprovado, bugs de
ffmpeg que silenciam áudio, timeout de wait que não é falha, e mais. Cada um com o fix.

## ADENDO: Motor cinético + pipeline MCP (22/07/2026, via skill vox-motion-graphics do Sanji Nai-Chien)

Pasta [references/vox-motion-graphics/](references/vox-motion-graphics/) (mcp-pipeline.md, vox-prompts.md, diorama-doc.md). O que este adendo ADICIONA ao nosso fluxo (sem substituir o pipeline aprovado de stills + first/last frame):

1. **Motor de história cinético** (usar em TODO filme daqui em diante): um OBJETO-FIO físico que atravessa e escala em todos os blocos; pergunta estampada num prop respondida só no kicker; **fake-oner** (todo clipe = UM movimento contínuo de câmera que começa E termina em motion blur, cortes secos viram plano-sequência falso); um impacto físico a cada ~3s (slam/carimbo/shockwave); speed ramp por bloco; whiplash de escala (macro extremo ↔ diorama wide); UM reveal shot memorável por filme.
2. **Anatomia de block prompt pro gemini_omni** (vox-prompts.md): STYLE REFERENCE (style key anexada em TODO clipe) + SCENE + MOTION + AUDIO + NEGATIVE fixo. Regra da style key: 1 imagem-chave do estilo anexada como media em toda geração garante consistência entre cena 1 e cena N. `aspect_ratio` SEMPRE explícito (a key não define o framing, verificado).
3. **Estilo diorama cinematográfico** (diorama-doc.md): o irmão cinematográfico do nosso mundo, com style key pronta, props reutilizáveis via image_references ("the X from the reference image"), tipografia letterpress EM props (1 label por cena, com fence no negative), e o shape completo do fake-oner com exemplo real.
4. **Escolha de engine**: gemini_omni (30cr, workhorse, renderiza semelhanças de figuras públicas) vs seedance_2_0 (45/90cr, cortes in-prompt, speed ramps reais, SFX nativo com generate_audio: true que sobrevive sob o VO). Mapa de moderação testado: político nomeado no prompt de vídeo falha no seedance (nome só no VO); rosto reconhecível em close falha no seedance mas passa no omni; "mushroom cloud" = nsfw; server empurra preset_recommendation: recusar com declined_preset_id.
5. **Rota MCP** (mcp-pipeline.md): pipeline completo via Higgsfield MCP: blocos de 10s (N = minutos × 6, VO ~20-24 palavras/bloco), style key por resolve_explainer_preset ou nano_banana_pro, voz seed_audio (verificar durationSec real de cada take: alvo 9.0-10.5s), e montagem server-side `explainer_video` (clipe+take por bloco, legenda queimada) como ALTERNATIVA ao Hyperframes. Re-voice multi-idioma: mesmo visual, novo VO por idioma, custo quase zero.
6. **Quando usar o quê**: storyboard aprovado tela a tela + FLF (nosso padrão) quando o cliente aprova frames e o controle exato importa; block-prompt direto com style key quando a velocidade importa e não há aprovação prévia de stills. Nos dois casos, o motor cinético do item 1 entra na coreografia.

## Regras operacionais

- Outputs por projeto/run em subpasta própria com `raw/`, `final/`, `INDEX.md`
  (computer:// links + prompts reproduzíveis + créditos gastos). Nunca output solto.
- **Nunca renomear/mover/sobrescrever arquivo já entregue** (editores referenciam por
  path). Só ADICIONAR com nome novo e dizer qual é o escolhido. Versões quebradas vão
  pra `_descartados/`, avisando.
- Geração paga: sequencial (controle de custo), com log `batch.log` (JOB/OK/FAIL) e
  monitor. `higgsfield generate wait` que estoura timeout NÃO é falha, re-rodar o wait
  com o job id e parsear `result_url` via python json.
- Ao finalizar: pasta final em link clicável + arquivos gerados (não-.md) em links.
- QC sempre em 3 eixos: **fatos** (allowlist da marca), **tom** (sem acusação/sarcasmo
  contra terceiros; humor no problema, nunca em pessoas), **visual** (spelling letra a
  letra, sem micro text, sem logo inventado, estilo preservado, marca presente).
