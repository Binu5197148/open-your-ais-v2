# Assets

The image assets that sit here in the private version of this skill are **not**
included in this release:

- `refs-futurista/`, 9 style reference images. Left out because their origin
  was not verified for redistribution.
- `exemplos/`, 4 approved output cards from a real client production. Left out
  because the work belongs to the client.

Nothing in `SKILL.md` or `references/` points at these files, so the method, the
style blocks, the prompt anatomy and the lessons all work without them.

What the futurist reference vocabulary covered, described so you can build your
own set: cutout figures among blurred newsprint; a 3D monolith with a label on
top; a bar or scale with a black and white photo behind it; figures next to an
inflated chunky-paper object; a folded newsprint valley with diverging lines; a
racetrack in perspective with figures; a canyon of torn newspaper; a newsprint
corridor with an explosion at the vanishing point; a macro tech object in
halftone.

One rule carried over from those references: they use red as the accent colour.
In production the accent becomes the brand's colour, never red by default. That
was the first lesson paid for on a real job.
