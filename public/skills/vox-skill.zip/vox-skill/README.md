# vox-skill

A paper-collage explainer factory: locked style blocks, precision typography rendered in PIL with a real font file, voiceover aligned by beats, and a catalogue of lessons paid for on a real production.

From the working skill library of Ulisses Balbino. Released at
https://openyourais.com/skills/

Instructions are written in: Portuguese

## Install

```
# Claude Code, available in every project
unzip vox-skill.zip -d ~/.claude/skills/

# or scoped to one repo
unzip vox-skill.zip -d .claude/skills/
```

You should end up with `vox-skill/SKILL.md`. Start a new session so the
skill is picked up.

## Needs

Higgsfield CLI. Python with PIL. ffmpeg. whisper-cli for voiceover alignment. An editor for assembly.

## What changed before release

The whole binary assets folder was removed: 9 style reference images whose origin was not verified, and 4 output cards from a client production. assets/README.md describes what was in it and how to rebuild it.

---

Shared as is, no warranty. It names third party tools and models, and
those age fast. Check what a job costs before you let an agent spend.
