# Anatomia de prompt: animação de telas no gemini_omni (e similares)

Extraída de referência real (explainer profissional que mostrava os próprios prompts na
tela) e validada em produção. Meus prompts iniciais ("slow, gently, subtly, hold still")
geravam animação morta, esta anatomia resolveu.

## Estrutura: STYLE / SHOT / AUDIO / AVOID

### STYLE (escrito 1x, colado VERBATIM em todo clipe)
Não descreve layout, descreve o SISTEMA físico e de câmera:

> "deep 3D paper diorama, cutouts are physical layers separated in real space, strong
> shallow depth of field, true parallax, foreground elements crossing close to the lens,
> the camera is an actor: it flies between layers, orbits, dives, whips, racks focus,
> one committed cinematic move per clip, springs with overshoot, staggered entrances,
> never glossy CG 3D"

⚠️ NÃO usar "ticking counters" no STYLE, induz o modelo a inventar etiquetinhas com
números aleatórios em qualquer cena "econômica".

### SHOT/ACTION (única parte que muda por clipe)
- Elementos por profundidade: BG / MG / FG.
- Ordem de entrada staggered (o que entra primeiro, o que responde).
- **UM movimento de câmera comprometido por clipe** (one move per clip). O vocabulário
  aceita qualquer técnica: orbit, whip, dive, rack focus, hyperlapse, dolly zoom,
  crash zoom, o que der o tridimensional.
- Motion blur no elemento mais próximo da lente.
- TEXT ON SCREEN entre aspas.
- Sempre termina com "Settle on ..." (estado final).
- **Coreografia com tempo explícito quando o resultado importa**: "At second 0...
  From second 2 to 4... the counter rolls wheel by wheel: $, 2, 0, comma, 0, 0, 0, +".
  A IA não pode ter que adivinhar NADA.

### AUDIO
Sound design only, no music, no narration. (Mesmo que o áudio seja descartado depois,
o bloco molda a energia da animação. MELHOR: não descartar, ver lição de SFX.)

### AVOID (negative list, cresce com os erros do projeto)
Base: no flat single-plane composition, no static locked-off camera, no glossy plastic
CG, no warped/gibberish text, no invented logos, no watermarks, no music, no voice-over.
Adições validadas:
- "absolutely no new digits or numbers beyond what is already printed in the frame,
  no number tickets or tags"
- "every facade sign stays spelled EXACTLY '<TEXTO>'" (quando há texto repetido em cena)
- "no circular stamps or seals, no micro text"
- guard de produto: "the <produto> stays EXACTLY as in the reference image, do not
  redesign it, no invented buttons or logos"

## Beats com texto crítico

"**Static camera**" no SHOT, o movimento vem dos OBJETOS (carimbos batendo, contadores
rolando, underlines varrendo), nunca da câmera. Câmera + texto = texto deformado.

## Técnica de item-refs (multishot com âncoras)

Além da tela inteira, anexar como referências extras os CROPS dos itens-chave
(via PIL, custo zero): `--medias [tela_inteira, crop_item1, crop_item2, ...]`.
Evita itens "se desfazendo" no meio do clipe. Para finais exatos (ex: contador
terminando num número específico), anexar também a IMAGEM DO ESTADO FINAL como última
referência e escrever no prompt que o clipe termina exatamente nela.

## Padrão de execução (Higgsfield CLI)

```zsh
up(){ higgsfield upload create "$1" --json 2>&1 | grep -oiE '[0-9a-f-]{36}' | head -1 }
gen(){ local name=$1 prompt=$2; shift 2
  local medias="["; local first=1
  for img in "$@"; do local U=$(up "$img")
    [ $first = 1 ] && first=0 || medias+=","
    medias+="{\"role\":\"image\",\"data\":{\"id\":\"$U\",\"type\":\"media_input\"}}"; done
  medias+="]"
  local J=$(higgsfield generate create gemini_omni --prompt "$prompt" --medias "$medias" \
    --duration 8 --aspect_ratio 16:9 --json 2>&1 | grep -oiE '[0-9a-f-]{36}' | head -1)
  echo "JOB $name $J" >> batch.log
  local R=$(higgsfield generate wait "$J" --timeout 15m --json 2>&1)
  local URL=$(echo "$R" | python3 -c "import sys,json;print(json.load(sys.stdin).get('result_url') or '')" 2>/dev/null)
  [ -z "$URL" ] && URL=$(echo "$R" | grep -oE 'https://[^ "]+\.mp4' | head -1)
  [ -n "$URL" ] && curl -sL "$URL" -o "clips/$name.mp4" && echo "OK $name" >> batch.log \
    || echo "FAIL $name (wait $J)" >> batch.log
}
```
- `wait` que estoura timeout: o job CONTINUA no servidor, re-rodar `higgsfield generate
  wait <job>` e parsear `result_url` (grep por .mp4 perde URL sem extensão; usar python).
- Saída Omni: 720p sem tag de color space → ver seção de cor no video-pipeline.

## Stills (gpt_image_2): regras de prompt

- Prompt = STYLE-BLOCK verbatim + "ACTION: <descrição da tela>" + TAIL (safe zones).
- Spelling guard em texto de risco: "spelled exactly 'PAYING', P-A-Y-I-N-G, six
  letters, a single letter I", modelos duplicam letras em stencil.
- "no other words anywhere" / "the only digits in the image are X, Y" fecha a porta
  de texto fantasma.
- gpt_image_2 NÃO aceita 4:5 → gerar 3:4 e cropar (ver carousel-pipeline).
