# Style-blocks catalogados + como criar um novo

Regra de ouro: o style-block é escrito UMA vez, refinado, salvo em .txt e colado
VERBATIM em todo prompt do projeto (stills e cards). Nunca parafrasear entre prompts,
paráfrase = deriva de estilo. `{ACCENT}` = cor de acento da marca do projeto.

## 1. Vox clássico engraved (documentário histórico)

```
Documentary paper collage in the style of a premium explainer film. Background: an aged
antique world map on heavily textured old paper, faded and warm. Elements are physical
paper cutouts with torn white edges: 19th-century engraved illustrations with dense
crosshatch etching shading (buildings, hands, objects, figures), torn paper scraps,
vintage postage stamps, rubber-stamp seals. Typography is bold condensed ALL-CAPS
stencil, stamped ink texture, on torn paper labels. Palette: warm cream and aged paper,
carbon black ink, saturated {ACCENT} as the single dominant accent, faded mustard
yellow as secondary support. Flat collage look with soft real drop shadows. No glossy
CG, no photography, no modern gradients, no micro text, no watermarks.
```

Quando usar: temas "história/como chegamos aqui", tom de arquivo, marcas sóbrias.

## 2. Vox futurista newsprint (o preferido: editorial contemporâneo)

```
Modern editorial documentary collage, in the style of a contemporary explainer film: a
physical paper diorama photographed with a cinema lens. Strong shallow depth of field,
foreground and background layers melt into soft blur, sharp focus only on the hero
plane. Backgrounds are dense stacked layers of aged newsprint: newspapers, financial
pages and headlines heavily defocused into warm sepia-cream bokeh, tactile paper fiber
visible everywhere. Hero elements are physical cutouts with thin white sticker borders
and soft real drop shadows: black-and-white photographic cutout figures (always
anonymous generic people of diverse ethnicities and genders, faces turned away or
softly blurred, never a real or recognizable person) and chunky 3D paper-sculpture
objects, monoliths, torn-newsprint canyon walls, paper star bursts, folded ramps,
built from creased and torn newspaper with visible edges and fibers. Typography is bold
condensed ALL-CAPS stamped stencil ink on torn cream paper labels, slightly weathered,
generously sized. Palette: saturated {ACCENT} as the single dominant accent, matte,
ink-like, weathered paper, never glossy; warm newsprint cream and sepia; carbon black.
NO other strong accent colors. Any brand element (web address pill, product screen)
uses the brand's clean typography, never stencil. Mood: investigative, kinetic,
contemporary documentary infographic. Absolutely no 19th-century etched or engraved
illustrations, no crosshatch woodcut style, no antique maps, no glossy CG 3D rendering,
no micro text, no tiny numbers or ticker digits, no gibberish lettering, no watermarks,
no real-person likeness, no invented logos or brand marks of any kind.
```

Vocabulário de heros que funcionam (validados): monolito/obelisco com label no topo;
placas verticais nomeadas (com "mordida" rasgada = perda); placas desabando atrás do
produto intacto (colapso→solução); seta 3D subindo escadaria com produto no topo;
corredor de newsprint com produto no ponto de fuga e figuras caminhando; explosão/burst
de papel atrás do produto hero; mapa de país em papel 3D; mãos P&B trocando objeto com
seta conectando; anos/datas em scraps desfocados ao fundo.

**Este estilo é a melhor base pra VÍDEOS futuros**: cada card é praticamente um still
pronto pra animar no Omni com a anatomia de prompts (os cards viram storyboard).

## 3. Clean publicitário (posts híbridos foto+PIL)

Não tem style-block gerado, é fotografia editorial minimalista + tipografia real:
- Camada 1 (gpt_image_2): "Minimalist editorial studio photograph of <UM objeto>,
  seamless very light warm background, soft diffused light, one soft realistic shadow,
  high-end product photography, generous negative space. Absolutely no text, no words,
  no letters, no numbers, no typography, no logos, no watermarks."
- Camada 2 (PIL): headline/sub na fonte oficial (.ttf), logo header, produto oficial
  colado. Paleta: acento da marca + near-black + fundos claros.

## Como criar um style-block NOVO a partir de referências

1. Usuário junta 8-12 imagens de referência numa pasta (+ um README descrevendo cada
   uma, se quiser orientar).
2. LER TODAS as imagens (visão), extrair o SISTEMA (não os layouts): material, luz,
   lente/DOF, tratamento de figura humana, tipografia, paleta com hierarquia
   (1 acento dominante), texturas, o que é proibido.
3. Escrever o style-block em 1 parágrafo denso: sistema físico → heros → tipografia →
   paleta → mood → negatives. Sempre terminar com a lista de proibições (inclui
   likeness real, logos inventados, micro text).
4. Salvar como `style-block-<nome>.txt` no projeto. Versionar quando o usuário mudar
   direção (v2, v3...), anotar no arquivo o que mudou e por quê.
5. Segurança: figuras sempre anônimas e diversas; tarja/censura nos olhos das refs NÃO
   entra (lê acusatório em anúncio), usar rostos de costas/desfocados.

## TAIL padrão (cola depois do ACTION em todo card)

```
Vertical portrait composition for an Instagram carousel card: generous breathing room
of empty defocused background at the very top edge, and keep the top-left corner area
(roughly the left third of the width and the top seventh of the height) completely
clear of any element or text, reserved for a logo watermark placed later. Big bold
stamped lettering only, generously sized, no micro text.
```
(+ proibições de cor do projeto, ex: "absolutely NO red or orange anywhere")
