# Pipeline de vídeo explainer Vox (30-90s)

## 0. Referência (obrigatório)
Dissecar um explainer real: baixar/transcrever (claudetube ou /watch), extrair frames
dos momentos-chave, e SE o criador mostrar os prompts na tela, copiá-los, foi assim
que nasceu a anatomia STYLE/SHOT/AUDIO/AVOID. Apresentar achados ao usuário e travar
a direção com ele ANTES de produzir.

## 1. Roteiro + VO + trilha (aprovar antes de gerar imagem)
- Roteiro em beats (6-8), cada beat = 1-2 telas. Estrutura validada: HOOK (número
  gigante/afirmação) → MUNDO (contexto/escala) → CULPADOS/BUSCA (tensão sem acusar
  ninguém nominalmente) → REVEAL (o mecanismo que ninguém conhece) → MARCA (a solução)
  → CTA (a virada).
- VO: TTS (ElevenLabs direto ou via Magnific `audio_tts`). Voz = decisão do usuário
  (dar 1 recomendação: grave/ressonante documental). ⚠️ Registrar as REGRAS DE
  PRONÚNCIA da marca (nome da marca soletrado como palavras separadas se o TTS engolir;
  ex: "BrandName" → "Brand Name"). Guardar o TEXTO FALADO EXATO, se um dia regravar
  (outra voz/idioma), transcrever o VO gravado e usar ESSE texto, não o roteiro escrito
  (a gravação sempre diverge do papel, e 1 palavra a mais desalinha tudo).
- Trilha: bed constante estilo documentário. Duração = filme + cauda pro fade.

## 2. Stills (uma tela por beat)
gpt_image_2, 16:9 (2k), style-block verbatim + ACTION + guards. Aprovação visual do
usuário tela a tela (ele dirige; regens são baratas aqui e caras depois).
Style-sheet aprovado da 1ª tela vira referência `--image` das seguintes (consistência).

## 3. Animação (gemini_omni, 8s por tela)
Anatomia completa em prompt-anatomy.md. Checklist por clipe:
- medias = [tela inteira] + [crops PIL dos itens-chave] (+ estado-final se houver
  contador/transformação exata).
- UM movimento de câmera; texto crítico = static camera.
- Coreografia com segundos explícitos.
- AVOID com os guards do projeto.
- O áudio nativo do clipe: **NÃO descartar por padrão**, extrair e guardar
  (`ffmpeg -i clip.mp4 -vn clip-audio.wav`). A camada de SFX sincronizada é o que
  separa "clipes bonitos" de "filme com molho" (lição paga: filme sem SFX foi
  reprovado mesmo com clipes elogiados).

## 4. Montagem
- **Hyperframes** (HTML composition): cortes nos beats do VO, `data-media-start` pra
  janelas limpas do clipe, zoom-cuts (mesmo clipe, scale 1.08, media-start avançado)
  pra variar sem gerar de novo, freeze-frame do último frame + GSAP zoom lento como
  end card, fade de opacidade no fim.
  - Lint exige UMA root composition (arquivar index antigos em `_archive/`).
  - Render: `npx hyperframes render . -q high -o renders/x.mp4` (argumento é o
    DIRETÓRIO do projeto).
- Retiming quando a ação não cabe na janela: `ffmpeg -vf "setpts=PTS/1.5"` comprime
  a ação 1.5x sem regen.
- Final precisa "acabar": trilha com fade-out real (afade 4s) + end card com micro
  zoom, hard cut de música lê como vídeo quebrado.

## 5. Cor (handoff pro Premiere do usuário)
Clipes de IA vêm com `color_space: unknown` → Premiere interpreta frio/lavado.
Entregar pasta `PREMIERE-CLIPS/` com TODOS os clipes transcodados e taggeados,
MESMOS NOMES (relink 1:1):
```
ffmpeg -i in.mp4 -vf "scale=1920:1080:flags=lanczos" -c:v libx264 -crf 14 -preset slow \
 -pix_fmt yuv420p -color_primaries bt709 -color_trc bt709 -colorspace bt709 \
 -color_range tv -movflags +faststart -an out.mp4
```
Fix rápido alternativo no Premiere: Lumetri Temperature +12~15 no clipe cru.
QC de cor de um export do usuário: amostrar frames a cada 2s e comparar lum/sat/R-B
com a versão de referência, apontar SÓ os trechos divergentes.

## 6. Troca de locução mantendo o corte (processo validado)
Quando o usuário já editou e precisa de VO novo (outra voz/sotaque/idioma):
1. Transcrever o VO ANTIGO com timestamps por palavra (whisper-cli, `-ml 1 -oj`) →
   extrair o texto FALADO exato e os STARTS de cada beat (grid).
2. Gerar o VO novo com ESSE texto. Se ficar mais longo que o grid, regenerar com
   leitura mais rápida (eleven_turbo respeita `speed`; v3 ignora) até ficar MAIS CURTO
   que o grid, nunca esticar/comprimir a voz digitalmente se evitável.
3. Transcrever o VO novo, achar os starts dos beats.
4. Montar: cortar o novo APENAS nos silêncios entre beats (nunca dentro de fala),
   fade 50-70ms nas bordas (em silêncio), posicionar cada beat pra FALA cair
   exatamente no start do grid antigo. Beats que o narrador emendou sem pausa ficam
   juntos num segmento só.
   - ⚠️ BUG CLÁSSICO ffmpeg: `-ss/-to` DEPOIS do `-i` com `-af` aplica o filtro no
     arquivo INTEIRO antes de cortar → segmentos além do primeiro fade viram SILÊNCIO.
     Sempre `-ss X -to Y -i src -af ...` (seek ANTES do input).
   - Fim de conteúdo = fim da última PALAVRA REAL (ignorar tokens de pontuação do
     whisper, que são pausa) e a cauda NUNCA cruza o início da fala seguinte -0.08s
     (senão entra um fragmento "Yo-" da próxima palavra).
5. Loudness: medir o VO antigo (`loudnorm print_format summary`) e normalizar o novo
   pro MESMO Integrated LUFS, os níveis de mix do usuário continuam valendo.
6. **Verificar o ARQUIVO FINAL**: transcrever o áudio do MP4 entregue e conferir
   frase a frase + silencedetect (zero buracos). Entregar o vídeo montado (map 0:v
   copy, sem re-encode de vídeo) + stems separados (VO alinhado + trilha com fade),
   com instrução de offset na timeline.

## 7. Entrega
`ENTREGA/` com 1 arquivo por versão, nome com data, `_LEIA.txt` append-only
documentando cada versão e cada stem. Nunca sobrescrever entrega anterior.
