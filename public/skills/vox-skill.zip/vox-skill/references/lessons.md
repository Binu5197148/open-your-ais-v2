# Lições aprendidas (erros pagos, com fix)

Catálogo vivo, cada item custou crédito ou retrabalho real. Ler antes de produzir;
acrescentar novas lições ao final de cada projeto.

## Direção e conceito
1. **Nunca criar estética de cabeça.** O modelo replica a média estatística. Dissecar
   referência real primeiro; o usuário é o diretor criativo e escolhe a referência.
2. **Metáfora abstrata reprova em peça estática.** "Tá lindo mas não entendi" = morte.
   Card/post tem que passar no teste "entendeu em 1 segundo" sem ler legenda.
3. **Cor fora da marca reprova mesmo bonita.** "Lindo, mas não tem nada a ver com a
   marca." O acento da marca domina TODAS as peças; cores da referência que conflitam
   viram detalhe ou somem. Confirmar paleta com o usuário ANTES do batch, não depois.
4. **Clipes bonitos ≠ filme bom.** Um filme sem camada de SFX sincronizado foi
   reprovado com os mesmos clipes que foram elogiados um a um. Sound design é parte
   do estilo Vox, não acabamento.
5. **Um conceito pode ser insalvável.** Se a piada só funciona violando um fato (ex:
   "tabela de taxas" vazia quando outras taxas existem), não há copy que salve,
   matar o conceito e substituir, não remendar.

## Prompts e geração
6. **Modelos duplicam letras em stencil** ("PAYIING"). Spelling guard soletrado no
   prompt + QC letra a letra em TODO texto gerado. Retry só do card com erro.
7. **Modelos inventam logos e produtos.** Qualquer menção de marca no prompt pode
   materializar um logo fake em tela/objeto aleatório. Guards: "no invented logos or
   brand marks of any kind" no style-block + produto SEMPRE como foto de referência
   anexada ("exactly as in the reference image, do not redesign it").
8. **Modelos inventam números.** "ticking counters" no STYLE ou cenas "econômicas"
   geram etiquetas com dígitos aleatórios. Guard: "the only digits in the image are
   X, Y, no other numbers anywhere".
9. **Figuras humanas default = homem branco de terno.** Diversidade (etnias e gêneros)
   explícita em todo prompt com pessoas/mãos.
10. **Tarja preta nos olhos (estilo de algumas refs) lê acusatório em anúncio.**
    Anonimizar com rostos de costas/desfocados.
11. **Texto crítico + câmera em movimento = texto deformado.** Static camera, objetos
    se movem.
12. **`generate wait` que estoura timeout NÃO é falha.** O job termina no servidor:
    re-rodar o wait com o job id e parsear `result_url` via python json (grep por
    extensão perde URLs sem .mp4/.png).
13. **gpt_image_2 não aceita 4:5.** Gerar 3:4 e cropar. A folga vertical do 3:4 é
    ferramenta de layout (ancorar bottom/center/top por card), mas crop NUNCA corta
    texto nem a borda de um elemento com texto.

## Tipografia e marca
14. **Texto de precisão = PIL com .ttf real** sempre que o pipeline permitir. IA só
    gera texto quando o texto É a estética (stencil), e com guards.
15. **Logo pequeno "não está presente".** Header de marca ~380px em posts 1080px.
    Em colagem cheia, logo flat é ilegível → chip de papel rasgado atrás (on-style).
    Posição idêntica em toda a série.
16. **Nunca chutar coordenada sobre foto**: medir bounds do objeto (numpy/threshold
    com o valor certo: papel branco ≈ >244, não >235 que pega fundo cream) e
    auto-fit da fonte na largura útil. Colisão texto/valor = medir, reduzir, repetir.
17. **Claim restrito vale pra METÁFORA também, não só copy.** Objeto que implica
    benefício em tudo (lista vazia, "fees: none" genérico, carta "Dear fees") engana
    mesmo com sub correto, o objeto nomeia o escopo ou o conceito morre.

## Áudio e vídeo
18. **BUG ffmpeg clássico: `-ss/-to` depois do `-i` com `-af`** aplica filtro no
    arquivo inteiro ANTES do corte → todo segmento após o primeiro fade-out sai MUDO
    ("só gerou o início"). Seek SEMPRE antes do input quando houver filtro.
19. **Regravar VO: usar o texto FALADO (transcrito), não o roteiro escrito.** Uma
    palavra a mais ("dollars") desalinha o corte inteiro. E cifrão no texto TTS
    reinsere "dollars", escrever números por extenso do jeito falado.
20. **Nunca fatiar fala por dentro.** Cortar só em silêncio entre frases, fades de
    50-70ms em silêncio, beats emendados pelo narrador ficam juntos. Preferir
    regenerar com leitura mais rápida (turbo respeita `speed`; v3 ignora) a esticar
    digitalmente. Cauda de segmento nunca cruza o início da fala seguinte (-0.08s),
    senão vaza fragmento da próxima palavra.
21. **Fim de conteúdo = última PALAVRA REAL.** Tokens de pontuação do whisper são
    pausa, não fala, contá-los infla o segmento e cria overlap.
22. **Loudness do VO novo = LUFS medido do antigo** (loudnorm I=<medido>) pros níveis
    de mix do usuário continuarem valendo.
23. **Verificar o ARQUIVO ENTREGUE, não o intermediário**: transcrever o áudio do MP4
    final + silencedetect (zero buracos) antes de entregar. "Confere se tá me mandando
    certo" é parte do job.
24. **Clipes de IA sem tag de cor** → BT.709 explícito no transcode pro editor do
    usuário (pasta PREMIERE-CLIPS, mesmos nomes, relink 1:1). fps da timeline NÃO
    afeta áudio, não deixar o usuário caçar fantasma.
25. **Áudio nativo dos clipes de IA**: extrair e guardar SEMPRE (é SFX de graça,
    sincronizado por construção).

## Processo
26. **Aprovação textual antes de crédito.** Conceitos+copy → OK → geração. Rodada de
    correção também: diagnóstico → proposta → OK (exceto fix de custo zero).
27. **Sequencial com log + monitor.** batch.log (JOB/OK/FAIL), monitor no log,
    QC de cada peça ASSIM QUE sai (erro pego no card 2 não contamina o card 6).
28. **Interromper batch no meio é barato** (matar o script preserva o job em voo,
    recuperar com wait); gerar 4 cards na direção errada é caro. Ao primeiro sinal de
    "não é isso", pausar e realinhar.
29. **INDEX.md com prompts reproduzíveis + créditos + histórico de decisões.** O
    projeto seguinte começa do INDEX do anterior.
30. **Nunca renomear/mover/sobrescrever entrega.** Editores linkam por path. Só
    adicionar (com data/versão no nome) e apontar o escolhido; quebrados vão pra
    `_descartados/` avisando.
