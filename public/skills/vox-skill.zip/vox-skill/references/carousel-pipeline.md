# Pipeline de carrossel e single posts Vox

## Fluxo do carrossel (4:5, 5-8 cards)

1. **Copy dos cards primeiro** (tabela: papel narrativo / labels exatos / hero
   visual). QC de fatos (allowlist da marca), tom e escopo de claim. **Aprovação
   textual do usuário ANTES de gerar.** Flags [A]/[B]/[C]/[D] quando algo falhar QC.
2. **Arco narrativo validado**: HOOK (dado/afirmação forte) → MUNDO (contexto) →
   SHIFT (a virada estrutural) → WAVE (tendência) → MARCA (produto hero) → CTA
   (fechamento + pill com URL). Arco de COR: cards de problema podem ser neutros,
   mas o acento da marca DOMINA, e o card da marca é o clímax cromático.
3. **Geração sequencial** (gpt_image_2, 3:4 2k, o modelo NÃO aceita 4:5):
   prompt = style-block verbatim + "ACTION: <card>" + TAIL (safe-zone). Referências
   `--image`: style-sheet/card aprovado do estilo + foto oficial do produto em TODO
   card que o mostre.
4. **Crop 4:5**: janela 1080×1350 do raw 3:4, default ancorado embaixo (respiro no
   topo sai do corte). O raw tem folga vertical (~96px em escala final): usar
   center/top-anchored POR CARD se elemento importante ficar na borda, mas NUNCA
   deixar o crop cortar texto (se cortar, o problema se resolve no tamanho do badge
   ou regen, não no crop).
5. **Badge/watermark PIL** (marca em todos os cards):
   - Logo oficial (alpha real) redimensionado ~170-230px de largura.
   - Posição idêntica em todos os cards da série: topo-esquerdo (48, 36), por isso o
     TAIL reserva essa área no prompt.
   - Se o fundo for "cheio" (colagem): montar um CHIP de papel rasgado atrás do logo
     (PIL: polígono jittered em 2x + GaussianBlur + textura de ruído + sombra), fica
     on-style e legível sobre qualquer arte. Se ainda colidir com texto: reduzir o
     chip, nunca cobrir letra, nunca cortar texto com crop.
6. **QC visual card a card** (ler cada final em zoom):
   - Spelling LETRA A LETRA de todo texto (o modelo duplica letras: "PAYIING").
   - Nenhum dígito além dos aprovados; nenhum logo/marca inventado (guard no prompt:
     o produto só existe como a foto de referência).
   - Sem micro text; estilo preservado; diversidade nas figuras; badge legível.
   - Retry só do card com defeito, com o guard reforçado (spelling soletrado:
     "P-A-Y-I-N-G, six letters, a single letter I, never PAYIING").
7. **INDEX.md** do run: links computer:// dos finais, style-block usado, prompts
   reproduzíveis (ou referência ao generate.sh), QC, histórico de correções com o
   PORQUÊ, créditos gastos (incluindo retries).
8. Strips de QC (thumbnails lado a lado + faixa do topo com os badges) ajudam o
   usuário a aprovar de uma olhada.

## Regra de conceito: "entender em 1 segundo"

Antes de gerar qualquer card, teste: se você tampar os labels, a imagem ainda conta a
história? Metáforas abstratas bonitas (estrela, obelisco solto, canyon) REPROVAM em
estático, funcionam só onde há locução. Converter sempre pra literal:
- "5 intermediários cobram" → 5 mãos levando 1 nota cada de um pagamento.
- "plataformas colapsam a pilha" → as 5 placas desabando ATRÁS do produto intacto.
- "cresce rápido" → seta subindo escada com o produto no degrau mais alto.
- "o futuro" → corredor com o produto GRANDE no ponto de fuga e pessoas indo até ele.
O produto oficial como protagonista recorrente (3-4 dos 6 cards) = memorização.

## Single posts CLEAN (híbrido foto + PIL)

Para a linha "publicitária minimalista" (sacada conceitual + foto de estúdio + tipografia
limpa):

1. **Conceito por post** = 1 objeto + 1 sacada ("nossa papelada de saída" = folha em
   branco; "nosso número favorito" = 0 gigante 3D na cor da marca). Aprovar textual.
2. **Camada 1** (gpt_image_2, 3:4): cena fotorreal SEM TEXTO, negative obrigatório:
   "Absolutely no text, no words, no letters, no numbers, no typography, no logos,
   no watermarks". Posts 100% tipográficos nem geram (fundo sólido PIL, custo zero).
3. **Camada 2** (PIL): TODO texto na fonte oficial (.ttf real), logo header idêntico
   na série (~380px topo centro, logo pequeno "não está presente"), produto oficial
   colado quando entrar. Truques validados:
   - Auto-fit de fonte: reduzir size até `textlength` caber na largura útil MEDIDA
     (medir bounds reais do objeto na foto via numpy/threshold, com margem; nunca
     chutar coordenada).
   - Texto "manuscrito" em bilhete: fonte handwritten do sistema, rotacionar o layer
     pra casar com a inclinação do papel na foto.
   - Painel flutuante (extrato/tabela): retângulo branco arredondado + sombra
     gaussiana + linhas com leader de pontinhos, resolve texto sobre foto em
     perspectiva sem warp.
   - Objeto grande demais no frame: NÃO regenerar, estender o fundo com a própria
     coluna de gradiente da foto (crop 20px da borda → resize → blur) e reduzir a
     foto sobre ela com máscara feather; abre respiro pra tipografia de graça.
4. **Compliance de metáfora**: objeto que implica benefício irrestrito (ex: "tabela
   de taxas" em branco quando existem outras taxas) é claim enganoso, a piada tem
   que nomear o escopo exato ou morrer. Ver lessons.md.
