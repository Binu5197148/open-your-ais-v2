---
name: higgsfield
description: Generate AI videos and images via the Higgsfield CLI (veo3, seedance, kling, wan, cinematic studio, marketing studio, soul-id). Use when the user wants to create a video or image with Higgsfield, mentions higgs/hf/higgsfield, asks to render a shot, animate an image, run a Veo 3 / Seedance / Kling / Wan job, train a Soul reference, do a product photoshoot, or use Marketing Studio. Handles auth check, model selection, prompt building, media upload, cost estimation, job submission, and polling for results.
---

# Higgsfield Video & Image Generation

Use the local `higgsfield` CLI (aliases: `higgs`, `hf`) to run image, video, and Marketing Studio workflows from the terminal. The user has already authenticated (`higgsfield auth login`).

## Pre-flight checks

Before submitting any job:

1. Confirm auth: `higgsfield auth token` (silent if logged in; if it errors, tell the user to run `higgsfield auth login`).
2. Confirm workspace billing if multi-workspace: `higgsfield workspace list` → `higgsfield workspace use <id>` if needed.
3. Check credit balance for expensive jobs: `higgsfield account balance`.

Do **not** repeat these on every job in the same session, only when something fails or the user asks.

## Core workflow

### 1. Pick a model

Models are referenced by their `job_set_type` (the leftmost column in `model list`). Common video models:

| job_set_type | Notes |
|---|---|
| `veo3_1` | Google Veo 3.1. Params: prompt (req), aspect_ratio 16:9\|9:16, duration 4\|6\|8, model veo-3-1-preview\|veo-3-1-fast, quality basic\|high\|ultra, input_image |
| `veo3_1_lite` | Cheaper Veo 3.1 variant |
| `veo3` | Veo 3 original |
| `seedance_2_0` | Bytedance Seedance 2.0. Params: prompt (req), aspect_ratio, duration int, genre (action/horror/comedy/noir/drama/epic), mode std\|fast, resolution 480p\|720p\|1080p, medias |
| `seedance1_5` | Seedance 1.5 Pro |
| `kling3_0` / `kling2_6` | Kling video |
| `wan2_7` / `wan2_6` | Wan video |
| `grok_video` | Grok |
| `minimax_hailuo` | Minimax Hailuo |
| `cinematic_studio_3_0` | Higgsfield Cinematic Studio 3.0 |
| `marketing_studio_video` | Marketing Studio video |
| `soul_cast` | Soul Cast video (uses trained soul-id) |

Common image models include `nano_banana_2`. List all with `higgsfield model list` (add `--image`, `--video`, or `--text` to filter).

Inspect parameters before guessing: `higgsfield model get <job_set_type>`. The PARAM table shows accepted values and defaults, **never** invent parameter names; read them from the model.

### 2. Upload media if needed

If the user provides a local image/video/audio file:

```bash
higgsfield upload create ./path/to/file.png
```

Returns an upload UUID. Reuse via `higgsfield upload list --image` (or `--video`, `--audio`).

Shortcut: `generate create` accepts a local path on media flags (`--image`, `--start-image`, `--end-image`, `--video`, `--audio`) and auto-uploads. Use the shortcut for single-shot jobs; use explicit upload when reusing the same asset across multiple jobs.

### 3. Estimate cost (optional but recommended for expensive jobs)

```bash
higgsfield generate cost <job_set_type> --prompt "..." [--param value]...
```

Show the user the estimated credits before launching a Veo 3 / Cinematic Studio / multi-shot job.

### 4. Create the job

```bash
higgsfield generate create <job_set_type> \
  --prompt "your prompt" \
  --aspect_ratio 9:16 \
  --duration 8 \
  --image ./reference.png \
  --wait \
  --wait-timeout 20m \
  --wait-interval 5s
```

- Pass model params as `--name value`. Names come from `model get`.
- `--wait` blocks until the job finishes and prints the result URL(s). Use it unless the user wants fire-and-forget.
- `--wait-timeout` defaults are short for some models, bump to `20m` for Veo 3 ultra / long durations.
- Add `--json` (global flag) when you need to parse output programmatically.

### 5. Poll or inspect later

If you skipped `--wait`:

```bash
higgsfield generate list           # recent jobs
higgsfield generate get <job_id>   # one job
higgsfield generate wait <job_id> --wait-timeout 20m
```

## Prompt building rules

Higgsfield models respond best to **cinematic, structured prompts**, not Midjourney-style tag soup. Use this skeleton:

```
[shot type] of [subject], [action], [setting + time of day],
[camera movement], [lens/style], [lighting], [mood/tone].
```

Example for Veo 3.1:
> "Slow dolly-in on a vintage red sports car parked on a wet Tokyo street at night, neon reflections rippling across the hood, shot on 35mm anamorphic, shallow depth of field, cinematic moody lighting, Blade Runner aesthetic."

For Seedance 2.0, pick the right `genre` flag, it materially changes pacing and color grading.

For image-to-video jobs, keep the prompt focused on **motion and camera**, not subject description (the image already supplies that).

If the user has the `video-prompt-builder` skill or `nanobanana-prompt-builder` skill available and the brief is loose, suggest invoking that first.

## Soul-ID (custom character references)

To create a reusable character identity:

```bash
higgsfield soul-id create --name Alice --soul-2 \
  --image id1 --image id2 --image id3 --image id4 --image id5
higgsfield soul-id wait <soul_id>
```

Then pass the soul id to `soul_cast` or compatible models via the appropriate param (check `model get soul_cast`).

## Marketing Studio

For branded ad workflows (DTC Ads Engine, branded video, product cards):

```bash
higgsfield marketing-studio products create --title "Sneaker" --image <upload_id>
higgsfield marketing-studio webproducts fetch --url https://example.com --wait
higgsfield marketing-studio dtc-ads ...
```

Use Marketing Studio when the user mentions: ad creative, branded video, DTC, product ads, web product import.

## Product photoshoot

For brand-quality product images with backend prompt enhancement:

```bash
higgsfield product-photoshoot create --mode lifestyle_scene \
  --prompt "bottle for IG" --image bottle.jpg --count 3
```

Modes vary, check `higgsfield product-photoshoot create --help` if in doubt.

## Output handling

- Result URLs from `--wait` are HTTPS links to the rendered media on Higgsfield's CDN.
- Download with `curl -L -o output.mp4 "<url>"` if the user wants a local copy.
- For multi-output jobs (e.g. `--count 3`), the CLI prints one URL per result.

## Common gotchas

- **Don't hand-craft model names**: always use `model list` then `model get` to confirm the exact `job_set_type` and parameter spelling.
- **Veo 3 quality `ultra` is expensive**: confirm with the user before running.
- **Duration is integer for some models, enum for others**: `model get` is the source of truth.
- **Aspect ratio defaults to 16:9**: explicitly pass `9:16` for vertical/social.
- **Media flag accepts paths**, but if the same asset is reused across N jobs, upload once and reuse the id to avoid re-uploading.
- **Background jobs**: for long renders, use `Bash(run_in_background: true)` so the conversation isn't blocked. You'll be notified on completion.

## Workspace & account

```bash
higgsfield workspace list
higgsfield workspace use <workspace_id>
higgsfield account balance
higgsfield account transactions
```

## Reference

- CLI binary: `higgsfield` (also `higgs`, `hf`)
- Help on any command: `higgsfield <command> --help`
- Raw JSON output for parsing: append `--json` to any command
- Disable ANSI colors in scripts: `--no-color`
