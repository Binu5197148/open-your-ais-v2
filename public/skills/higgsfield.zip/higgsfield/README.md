# higgsfield

An operating manual for the Higgsfield CLI: pick the model by its job_set_type, read the parameters before guessing them, check the balance, upload media, wait for the job.

From the working skill library of Ulisses Balbino. Released at
https://openyourais.com/skills/

Instructions are written in: English

## Install

```
# Claude Code, available in every project
unzip higgsfield.zip -d ~/.claude/skills/

# or scoped to one repo
unzip higgsfield.zip -d .claude/skills/
```

You should end up with `higgsfield/SKILL.md`. Start a new session so the
skill is picked up.

## Needs

The Higgsfield CLI on your PATH, authenticated.

## What changed before release

Nothing.

## Credit

This documents a third party CLI. Model names, parameters and prices change. Confirm with `higgsfield model list` and `higgsfield model get` before trusting any table in here.

---

Shared as is, no warranty. It names third party tools and models, and
those age fast. Check what a job costs before you let an agent spend.
