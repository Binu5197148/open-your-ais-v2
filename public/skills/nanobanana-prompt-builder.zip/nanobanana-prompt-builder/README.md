# nanobanana-prompt-builder

Writes six-layer image prompts for Nano Banana Pro: subject, composition, lighting, material, colour, technical, then assembles them into one dense block ready to paste.

From the working skill library of Ulisses Balbino. Released at
https://openyourais.com/skills/

Instructions are written in: English

## Install

```
# Claude Code, available in every project
unzip nanobanana-prompt-builder.zip -d ~/.claude/skills/

# or scoped to one repo
unzip nanobanana-prompt-builder.zip -d .claude/skills/
```

You should end up with `nanobanana-prompt-builder/SKILL.md`. Start a new session so the
skill is picked up.

## Needs

Nothing. The output is a prompt.

## What changed before release

Added the YAML frontmatter the file was shipping without. Removed five mentions of a client series name; the worked example stays, unnamed.

---

Shared as is, no warranty. It names third party tools and models, and
those age fast. Check what a job costs before you let an agent spend.
