---
name: nanobanana-prompt-builder
description: Build layer-structured image prompts for Nano Banana Pro (nano-banana-2). Six mandatory layers, subject, composition, lighting, material, colour and technical, assembled into one dense prompt ready to paste. Use when the user asks for an image prompt, a product hero shot, a character image, or wants a loose visual brief turned into a generation-ready prompt.
---

# Nanobanana Pro: Image Prompt Builder

Builds professional, layer-structured image prompts for Nanobanana Pro (nano-banana-2 via Kie AI).
Every output follows a six-layer anatomy designed to give the model maximum specificity on subject,
composition, lighting, materials, colour, and technical direction.

## Project context

Default output spec: **9:16 vertical, 2K resolution**, optimised for TikTok, YouTube Shorts,
and Instagram Reels cover frames.

Model used: `nano-banana-2` via Kie AI API.
Primary use cases: recurring character series, product hero shots, branded editorial imagery.

## How this skill works

1. The user provides a **creative brief**, an image description, a reference photo, a concept,
   or a style reference. They may also provide an existing image to riff on or a series to match.
2. Read the reference file at `references/image-anatomy-reference.txt` to calibrate depth and
   specificity before writing.
3. Generate the full six-layer prompt output, then assemble the **Final Assembled Prompt**,
   the version ready to paste directly into Kie AI.

## Input expectations

The user's brief can include any combination of:
- Subject description (character, food, object, scene)
- Reference image or existing visual in the series
- Mood, tone, aesthetic direction
- Specific details they want (colours, textures, expressions)
- Style references (photographer, brand, art movement)
- Whether this is a standalone image or part of a series (affects consistency guidelines)

If the brief is too vague (e.g. "something cool with food"), ask one focused clarifying question.
If a reference image is provided, describe what you observe before building the prompt, this confirms
you read it correctly before committing to a direction.

## Output structure

ALWAYS produce ALL SIX LAYERS plus the FINAL ASSEMBLED PROMPT. Never skip a layer.

---

### LAYER 1: CORE SUBJECT

Describe the primary subject with exhaustive specificity. This is the most important layer.

Write it as a single dense paragraph covering:
- What it IS (species, object, character type)
- What it is MADE OF (materials, construction logic)
- Surface quality of each material (finish, sheen, translucency)
- Spatial logic (how does it sit in space, what supports it)
- Expression, posture, gesture if the subject has a face or body
- Any secondary elements in direct contact with the subject (hands, props, food accessories)

**Rule:** Every noun needs a modifier. Not "strawberries", "fresh strawberries, partially sliced to
reveal the red interior, with visible achene indentations on the cut surface."

---

### LAYER 2: COMPOSITION

Describe the frame as a director blocking a shot:
- Camera angle (eye-level, low-angle, high-angle, dutch tilt) and direction (front, three-quarter, profile)
- How much of the subject is in frame (full body, bust, extreme close-up)
- Frame occupation: what percentage of the frame the subject holds, and where
- Secondary elements: where do hands, props, or supporting elements land in the frame
- Depth of field behaviour: what is sharp, where does it begin to soften, what is abstracted

**Rule:** Describe what the camera SEES, not what you want to feel. "The figure occupies the
centre two-thirds of the frame vertically" is better than "prominent, centred composition."

---

### LAYER 3: LIGHTING

Describe the complete lighting setup as a cinematographer would:
- Key light: source type (hard/soft/diffused), position (clock-face angle, height relative to subject),
  how it behaves on the subject's specific materials
- Fill light: source, temperature (give Kelvin if relevant), how it wraps the shadow side
- Rim/back light: only if present, describe exactly what it separates
- Material-specific light behaviour: cream catches light differently from sauce, which catches it
  differently from biscuit, describe each
- What the light implies about the environment (studio, café, outdoor, etc.)

**Rule:** Never describe mood without describing mechanics. "Warm" is not lighting.
"Soft diffused key from upper-right, 45° above horizontal, ~2700K ambient fill from background"
is lighting.

---

### LAYER 4: MATERIAL & TEXTURE

For every distinct material in the image, write a dedicated description covering:
- Surface quality at normal viewing distance
- Surface quality at close inspection (micro-texture, pore structure, grain)
- How the material behaves under stress (soft deformability, rigidity, flow)
- What distinguishes it from a similar material (cream cheese vs whipped cream vs fondant)
- Physical phenomena specific to that material (meniscus on a drip, subsurface scatter in dairy)

**Rule:** At least one paragraph per major material. No generic terms, "shiny" is not a texture.
"Wet syrup sheen with a raised meniscus at the leading edge of each rivulet" is a texture.

---

### LAYER 5: COLOR & ATMOSPHERE

- Name the dominant palette with hex-range references for the two or three key colours
- Name the accent palette (secondary colours, background elements)
- Describe the grade approach: saturation behaviour, shadow warmth/coolness, highlight character
- Establish constraints: what colour temperatures or tones must NOT appear
- Describe the background atmosphere through its light character (what does the bokeh imply
  about the environment)

**Rule:** Give the model constraints, not just permissions. "No cool tones anywhere in the frame"
prevents model drift as much as a positive colour description does.

---

### LAYER 6: TECHNICAL MODIFIERS

Close the prompt with the rendering and photographic language:
- Photographic genre (editorial food photography, collectible toy photography, brand hero shot)
- Lens character (focal length equivalent, 35mm wide, 85mm portrait, 135mm compression)
- Rendering-specific techniques to invoke (subsurface scattering for translucent materials,
  physical-based rendering for metallic surfaces)
- Negative guidance: list 4-6 specific things to avoid
- Final spec line: aspect ratio, resolution, style tag

**Rule:** Negative guidance belongs here, not scattered across other layers. Keep it clean:
"Avoid: plastic sheen on cream surfaces, oversaturated reds, symmetrical composition,
film grain, hard specular highlights."

---

### FINAL ASSEMBLED PROMPT

After all six layers, produce the complete assembled prompt, everything merged into a
single dense block of text ready to paste directly into Kie AI. This is the DELIVERABLE.

Format: plain paragraph text, no section headers, no bullet points. Continuous prose.
End with the technical spec line: `9:16 vertical, 2K, photorealistic.`

---

## Creative principles

1. **Materials drive everything.** Nanobanana Pro responds best to material descriptions.
   A subject described through its physical properties will always outperform one described
   through its emotional impact. Describe what it IS before what it FEELS LIKE.

2. **Specificity prevents drift.** The model fills unspecified areas with defaults, and defaults
   are generic. Every unspecified detail is a decision left to chance. Name the hex range.
   Name the Kelvin temperature. Name the surface behaviour.

3. **Series consistency requires anchors.** If the image is part of a series,
   identify the visual anchors that must repeat: doll eye style, cheek blush character, lighting
   temperature, background bokeh quality. State these explicitly even if they feel obvious.

4. **Negative guidance is not optional.** Every prompt should tell the model what NOT to do.
   Plastic sheen, hard specular, oversaturation, symmetrical framing, these are the model's
   default sins for food/character work. Name them.

5. **Physical logic makes surreal subjects believable.** A food-baby hybrid is absurd. What makes
   it work is physical consistency: the cream cheese has the right surface tension, the compote
   has a meniscus, the biscuit crumbles. When the physics are right, the concept lands.

---

## Series consistency: a worked example

A food-character series this skill was built on locked the anchors below. Copy the
shape, not the values: whatever you pick, these are the slots that MUST repeat in
every image of a series.

**Character anchors (repeat exactly):**
- Oversized circular black doll eyes with single catch-light
- Rosy blush circles on both cheeks (same position and softness each time)
- Chubby baby-doll proportions (large head, round torso, short limbs)
- Mouth state varies per scene but always reads as expressive, not neutral

**Lighting anchors (repeat exactly):**
- Soft diffused key from upper-right quadrant
- Warm ambient fill from background (~2700K)
- No rim light, no cool tones

**Compositional anchors (repeat exactly):**
- Three-quarter low-angle framing
- Shallow depth of field: face sharp, background abstracted
- Human hand visible in frame as feeder element
- Full figure visible from base to crown

**Background anchors (repeat exactly):**
- Warm bokeh (café/restaurant implied)
- Amber or gold bokeh circles
- Wooden or warm-neutral surface

---

## If something is unclear

Ask one question maximum. Make it specific:
- "What food/material is this character made of?"
- "Is this a new character or should it match the existing series style?"
- "Standalone image or part of a series?"

Never ask multiple questions at once. Make one creative decision on your own rather than
asking two questions.

---

## Files reference

- `SKILL.md`: this file (skill instructions)
- `references/image-anatomy-reference.txt`: detailed layer-by-layer reference with
  fully annotated example prompt and assembled final version
