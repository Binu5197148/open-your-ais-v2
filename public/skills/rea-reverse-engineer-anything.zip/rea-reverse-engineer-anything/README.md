# REA skill (reverse-engineer-anything)

Copy of the REA agent skill, from https://github.com/morluto/rea
(main branch, commit fb28ec1, October 13, 2026). MIT license, see LICENSE.
All credit to the REA project. Shared by Open Your AIs (openyourais.com).

The skill only teaches your agent how to use REA. The analysis tools come
from the REA MCP server, which you install with:

    npx rea-agents setup

Use Node.js 22, 24 or 26. Restart your agent afterwards.
For the latest version of everything, use the repository above.
Use it only on software you own or are authorized to examine.
See https://github.com/morluto/rea/blob/main/DISCLAIMER.md
