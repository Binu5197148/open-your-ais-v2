# scroll-world

Builds a landing page where scroll drives a camera that flies from scene to scene with no cuts, plus the AI generation pipeline that makes the scenes and the seams.

From the working skill library of Ulisses Balbino. Released at
https://openyourais.com/skills/

Instructions are written in: English

## Install

```
# Claude Code, available in every project
unzip scroll-world.zip -d ~/.claude/skills/

# or scoped to one repo
unzip scroll-world.zip -d .claude/skills/
```

You should end up with `scroll-world/SKILL.md`. Start a new session so the
skill is picked up.

## Needs

Higgsfield CLI, authenticated. ffmpeg and ffprobe. Python 3 with PIL if you want the background knockout. The scrub engine itself is vanilla JS and needs no framework.

## What changed before release

Nothing. The files went out exactly as they run here.

---

Shared as is, no warranty. It names third party tools and models, and
those age fast. Check what a job costs before you let an agent spend.
