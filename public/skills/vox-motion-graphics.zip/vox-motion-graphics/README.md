# vox-motion-graphics

Runs a narrated motion-graphics explainer end to end on the Higgsfield MCP: topic research, fact-checked script, locked style key, animated clips, voiceover, one assembled MP4.

From the working skill library of Ulisses Balbino. Released at
https://openyourais.com/skills/

Instructions are written in: English

## Install

```
# Claude Code, available in every project
unzip vox-motion-graphics.zip -d ~/.claude/skills/

# or scoped to one repo
unzip vox-motion-graphics.zip -d .claude/skills/
```

You should end up with `vox-motion-graphics/SKILL.md`. Start a new session so the
skill is picked up.

## Needs

Higgsfield MCP connected, with credits.

## What changed before release

Five Higgsfield job ids that only resolve inside the author's own account were replaced with placeholders. The prompt that regenerates the style key is still in the file, so nothing is lost.

---

Shared as is, no warranty. It names third party tools and models, and
those age fast. Check what a job costs before you let an agent spend.
