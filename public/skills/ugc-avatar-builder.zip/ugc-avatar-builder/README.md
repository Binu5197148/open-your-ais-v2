# ugc-avatar-builder

Writes six-layer image prompts for UGC avatars, engineered so the frame reads as a person filming themselves at home rather than as an ad.

From the working skill library of Ulisses Balbino. Released at
https://openyourais.com/skills/

Instructions are written in: English

## Install

```
# Claude Code, available in every project
unzip ugc-avatar-builder.zip -d ~/.claude/skills/

# or scoped to one repo
unzip ugc-avatar-builder.zip -d .claude/skills/
```

You should end up with `ugc-avatar-builder/SKILL.md`. Start a new session so the
skill is picked up.

## Needs

Nothing. The output is a prompt.

## What changed before release

Added the YAML frontmatter the file was shipping without. Removed one mention of a client series name.

---

Shared as is, no warranty. It names third party tools and models, and
those age fast. Check what a job costs before you let an agent spend.
