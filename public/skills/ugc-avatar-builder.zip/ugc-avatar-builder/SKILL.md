---
name: ugc-avatar-builder
description: Build layer-structured image prompts for ultra-realistic UGC avatars, an AI creator holding or using a product, framed to read as a phone video and not as an ad. Six layers plus a locked character anchor for series consistency. Use when the user asks for a UGC avatar, creator content for paid social, or a consistent avatar across many images.
---

# UGC Avatar Builder: Nanobanana Pro

Builds professional, layer-structured image prompts for ultra-realistic UGC (User Generated Content)
avatars using Nanobanana Pro (nano-banana-2 via Kie AI).

Every output is engineered to produce a single result: an image that looks like a real person
filmed themselves recommending a product. Not advertising. Not editorial. UGC.

## What this skill is for

UGC avatars are AI-generated "creators" used in paid social (TikTok, Meta Reels, YouTube Shorts)
to produce product content at scale. They replace or complement human UGC creators.

The output must survive a viewer who is scrolling at full speed and whose brain is
pattern-matching for authenticity signals. If any element reads as "produced," trust collapses.

Default output spec: **9:16 vertical, 2K resolution**

## How this skill works

1. The user provides a brief: character description (or none, you'll define one), product being
   held/used, platform context (TikTok, Reels, etc.), and any tone/vibe reference.
2. Read `references/ugc-anatomy-reference.txt` to calibrate before writing.
3. If the user is building a **series** (multiple images of the same avatar), establish the
   **Character Anchor** first and confirm it with the user before generating the full prompt.
   Consistency across a series requires the anchor description to be locked and reused verbatim.
4. Generate the full six-layer output + Final Assembled Prompt.

## Input expectations

The brief can include:
- Character description or demographic (age range, ethnicity, hair type, skin tone)
- Product being held or used (category, size, colour, label detail)
- Platform and context (TikTok beauty, Reels skincare, etc.)
- Vibe reference ("like a girl who found this on Amazon", "dermatologist energy but relatable")
- Setting (bedroom, bathroom, kitchen, car, outdoors)
- Whether this is a standalone image or part of a consistent avatar series

If the user doesn't specify ethnicity or appearance, choose a realistic mid-range default
(avoid stereotypes, avoid the AI default of Northern European features). Make the choice
transparent: state what you chose before writing the prompt.

If the user is building a series, do NOT generate a prompt until the Character Anchor
is confirmed. Get agreement on the face identity first.

## Output structure

ALWAYS produce ALL SIX LAYERS plus the FINAL ASSEMBLED PROMPT. Never skip a layer.

---

### LAYER 1: CHARACTER ANCHOR

The locked identity of this avatar. If this is a series, this section becomes the
master reference to reuse across every image.

Write one dense paragraph covering:
- Age range (give a 3-4 year span, not a single number)
- Skin tone with undertone variation (not just "medium", which parts are warmer, which cooler)
- Face shape and any natural asymmetry (name it explicitly, AI defaults to symmetry)
- Nose: shape and tip character
- Eyes: shape, iris colour with internal detail, lid character
- Lips: upper vs lower proportion, natural colour state
- Brows: shape, and whether one sits higher than the other
- Hair: colour, texture (natural state, not styled), thickness, how it falls around the face

**Rule:** Name asymmetries. If you don't describe them, the model will generate a symmetrical
face that reads as AI-generated. "Left brow approximately 2-3mm higher than the right" is
the difference between a real face and a render.

---

### LAYER 2: AUTHENTICITY LAYER

The imperfections that make the character real. This layer is what separates
a believable UGC avatar from an obvious AI face.

Cover:
- Pore visibility: where and how visible (nose, upper cheeks, not everywhere)
- Any blemishes, spots, or faded marks (one is enough, name location and visibility level)
- Under-eye area: natural shadow quality (distinguish from dark circles)
- Skin shine zone: T-zone oil vs cheek matte (never fully matte, never fully glossy)
- Any freckles: quantity, location, colour intensity
- Lip texture: natural line character, not smooth
- Neck/jaw transition: unretouched

**Rule:** Describe what exists, not what to avoid. "One faded small blemish at the left chin,
not prominent" is better than "some natural imperfections." The model needs to know what to
render, not what to suppress.

---

### LAYER 3: PRODUCT INTEGRATION

How the product sits in the image. The most common UGC prompt failure.
The product must look like it belongs in someone's hand, not in an advertisement.

Cover:
- Which hand holds it (left or right) and the grip type (casual, specific finger positions)
- Orientation and tilt angle (almost never perfectly straight at camera)
- Label visibility percentage (70-80% facing camera is readable without being staged)
- Hand position in frame (height, horizontal offset from centre)
- Evidence of use: residue, open cap, partially squeezed tube, used packaging
- The other hand: where is it, what is it doing (even if barely in frame)
- Product condition: is the packaging pristine or does it look like it's been used before?

**Rule:** The label should never be perfectly centred and perpendicular. That is how products
are photographed for catalogues. Real people hold things casually.

**Product-specific notes:**
- Skincare bottle: grip with 3 fingers, tilted, dropper or pump visible
- Supplement/vitamin: one in the palm, others slightly blurred in background
- Beauty device: two-hand hold, device in use position (on face/skin, not presented at camera)
- Food/drink: relaxed one-hand hold, slight lean, partial label
- Small object (serum, lip balm): pinched between thumb and index, at chest height

---

### LAYER 4: ENVIRONMENT

The space that proves this was filmed at home.

Cover:
- Room type (bathroom, bedroom, kitchen, living room, car interior)
- Specific background elements in soft focus (name them, give their frame position)
- Surface the person is in front of (counter, wall, shelf, door)
- What is deliberately NOT there (no neutral photography backdrop, no ring light visible,
  no professional equipment)
- Degree of focus abstraction: domestic backgrounds should be soft but recognisable,
  not the round studio bokeh of a product shot, but blurred enough to not compete

**Rule:** Name 2-3 specific real objects in the background. Vague "cluttered bathroom" is not
enough. "A small open wooden shelf with 2-3 indistinct product shapes" is a specific real detail.

---

### LAYER 5: LIGHTING & CAMERA FEEL

The most important technical layer for UGC believability.
The goal: the viewer should believe this was filmed on a phone.

Cover:
- The practical light source and its position relative to the subject (window, overhead,
  lamp, and its clock-face angle from the camera axis)
- Soft vs hard light (overcast window = soft; sunny window = directional)
- Shadow ratio: how dark is the shadow side relative to the lit side (describe in stops
  or in plain language: "barely there shadow" vs "soft but visible shadow")
- Catch-light: one eye only (phones and single windows create one catch-light,
  not two identical ones), position in the eye (clock-face notation)
- Camera character: describe the phone-camera optical feel, slight outer-frame softening,
  near-uniform focus from face to mid-ground, only the far background abstracted
- Subject-to-camera distance: approximately 50-70cm (arm's length or short tripod)

**Rule:** Describe catch-lights by eye. Two identical catch-lights in both eyes read as
studio photography. A single catch-light in one eye, soft and non-geometric, reads as
a window or ambient source.

**Never use:** ring light visible in eyes, two-point lighting, beauty dish character,
rim lighting, uniform fill.

---

### LAYER 6: EXPRESSION & BODY LANGUAGE

The emotional and physical state of the person.

Cover:
- Expression: name the specific social moment (mid-sentence, just reacted, about to speak,
  listening face), not "smiling" or "happy"
- Eye direction: to lens (direct) or slightly off-lens (as if looking at own screen)
- Brow state: the micro-expression (mild enthusiasm, mild surprise, concentration)
- Mouth state: slightly open (mid-word), closed and relaxed, partial smile showing teeth
- Posture: shoulder alignment (one always slightly lower in natural posture),
  head tilt if any (natural conversational tilt is 5-10°)
- Energy level: conversational vs enthusiastic vs calm and informational

**Rule:** The expression should name the MOMENT, not the mood. "Mid-sentence explaining
something she just tried" is more useful to the model than "friendly and approachable."

---

### FINAL ASSEMBLED PROMPT

Merge all six layers into one continuous prose block. No headers, no bullets.
End with the technical and negative guidance line.

Format close: `9:16 vertical, 2K, photorealistic. Style: UGC phone content, not editorial
photography, not advertising. Avoid: [list 6-8 specific items].`

---

## Character Anchor management (for series)

When the user is building multiple images of the same avatar:

1. After writing the Character Anchor in Layer 1, present it separately and explicitly
   labelled as the SERIES ANCHOR.
2. Ask for confirmation before writing the rest of the prompt.
3. On subsequent images in the series, paste the Character Anchor verbatim, do not paraphrase.
4. Only Layers 3-6 change between images in the same series. Layers 1-2 are locked.

If the user reports inconsistency between generated images, the solution is almost always
adding more specificity to the Character Anchor, not changing the generation settings.

---

## Creative principles

1. **Authenticity over beauty.** A UGC avatar does not need to be conventionally attractive.
   She needs to be believable. A natural blemish contributes more to performance than
   perfect skin does.

2. **The product is secondary.** In UGC, the person's face and presence carry the trust.
   The product is proof, not the subject. When in doubt, make the face more interesting
   and the product hold more casual.

3. **One anchor, locked.** Character consistency across a series is the entire value of
   the avatar. The face must be the same person across 10 different product images.
   The Character Anchor is sacred, it does not change.

4. **Platform-specific tells matter.** TikTok UGC reads slightly different from Reels UGC.
   TikTok: more casual, slightly messier environment, more energy in expression.
   Reels: slightly more composed, but still natural. State the platform in the technical line.

5. **Negative guidance is product-specific.** A skincare UGC avatar needs different negative
   guidance from a supplement avatar. Skincare: avoid plastic skin, avoid clinical lighting.
   Supplements: avoid gym-photo aesthetic, avoid performance-sport framing.
   Tailor the avoid list to the product category.

6. **Distance creates trust.** The 50-70cm phone-camera distance is a social signal.
   It says "I'm talking to you from my bathroom, not from a studio." Maintain it.

---

## Platform context notes

**TikTok beauty/skincare:**
Slightly more casual environment. Kitchen or bathroom. Energy: warm, fast-talking, slightly
excitable. Expression often more open and enthusiastic. Lighting can be slightly imperfect.

**Instagram/Meta Reels, wellness/lifestyle:**
Slightly more composed. Bedroom or living room. Energy: calm, trustworthy, informational.
Expression: more measured. Lighting can be slightly better but still natural window.

**YouTube Shorts, product review:**
Can be slightly more formal. Home office or living room. Expression: neutral-to-positive,
informational. Slightly longer lens feel (70-85mm equiv.) compared to TikTok.

---

## Files reference

- `SKILL.md`: this file
- `references/ugc-anatomy-reference.txt`: full layer-by-layer anatomy with annotated
  examples, the six AI default errors and how to fight them, and a complete assembled
  reference prompt
