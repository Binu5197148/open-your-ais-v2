#!/usr/bin/env python3
"""world-film assembler: normalize -> concat (hard) or chained xfade -> audio mux.

Stdlib + ffmpeg/ffprobe only; runs on macOS, Linux and Windows.

Assemble (clips in CHAIN ORDER):
  python3 assemble.py --out film/master.mp4 clip1.mp4 clip2.mp4 clip3.mp4
  python3 assemble.py --out film/master.mp4 --xfade 0.2 clip1.mp4 clip2.mp4 ...
  python3 assemble.py --out film/master.mp4 --setpts 0.9 --trim-tail 0.5 clips...

Score an existing master:
  python3 assemble.py --remux film/master.mp4 --audio trilha.mp3 --afade-out 1.5 \
      --out film/master_scored.mp4

Seam QA (reads <master>.seams.json written at assembly time):
  python3 assemble.py --seam-report film/master.mp4 --frames-dir frames/qa

Hard concat of normalized clips is the default: frame-identical seams make the cut
invisible. --xfade is the fallback for a seam with visible render drift; it can never
hide a content jump (fix the frames, not the fade).
"""
import argparse, json, os, subprocess, sys

def sh(cmd, **kw):
    print("+ " + " ".join(str(c) for c in cmd), flush=True)
    subprocess.run([str(c) for c in cmd], check=True, **kw)

def probe(path):
    out = subprocess.run(
        ["ffprobe", "-v", "error", "-select_streams", "v:0",
         "-show_entries", "stream=width,height,r_frame_rate",
         "-show_entries", "format=duration", "-of", "json", path],
        capture_output=True, text=True, check=True).stdout
    j = json.loads(out); st = j["streams"][0]
    num, den = st["r_frame_rate"].split("/")
    return {"w": st["width"], "h": st["height"],
            "fps": float(num) / float(den or 1),
            "dur": float(j["format"]["duration"])}

def normalize(clips, norm_dir, fps, w, h):
    """Re-encode every clip to identical fps/size/encoder so concat -c copy is safe."""
    os.makedirs(norm_dir, exist_ok=True)
    normed = []
    for i, c in enumerate(clips):
        dst = os.path.join(norm_dir, "n%02d.mp4" % i)
        sh(["ffmpeg", "-v", "error", "-y", "-i", c, "-an",
            "-vf", "scale=%d:%d:flags=lanczos,fps=%g" % (w, h, fps),
            "-c:v", "libx264", "-preset", "slow", "-crf", "18",
            "-pix_fmt", "yuv420p", "-movflags", "+faststart", dst])
        normed.append(dst)
    return normed

def hard_concat(normed, out):
    """Concat demuxer with RELATIVE paths, run from inside the norm dir (house rule)."""
    norm_dir = os.path.dirname(normed[0])
    lst = os.path.join(norm_dir, "list.txt")
    with open(lst, "w") as f:
        for n in normed:
            f.write("file '%s'\n" % os.path.basename(n))
    sh(["ffmpeg", "-v", "error", "-y", "-f", "concat", "-safe", "0",
        "-i", "list.txt", "-c", "copy", os.path.abspath(out)], cwd=norm_dir)

def xfade_concat(normed, out, fade, fps):
    """Chained xfade: offset_k = sum(d_0..d_k) - (k+1)*fade."""
    durs = [probe(n)["dur"] for n in normed]
    inputs, filt, acc = [], [], ""
    for n in normed:
        inputs += ["-i", n]
    prev = "[0:v]"
    offset = 0.0
    for k in range(1, len(normed)):
        offset += durs[k - 1] - fade
        lab = "[v%d]" % k if k < len(normed) - 1 else "[vout]"
        filt.append("%s[%d:v]xfade=transition=fade:duration=%g:offset=%.3f%s"
                    % (prev, k, fade, offset, lab))
        prev = lab
    sh(["ffmpeg", "-v", "error", "-y"] + inputs +
       ["-filter_complex", ";".join(filt), "-map", "[vout]",
        "-r", "%g" % fps, "-c:v", "libx264", "-preset", "slow", "-crf", "18",
        "-pix_fmt", "yuv420p", "-movflags", "+faststart", out])

def post(src, out, setpts, trim_head, trim_tail):
    """Optional uniform speed + head/tail trims (NEVER trims a seam mid-chain)."""
    dur = probe(src)["dur"]
    args = ["ffmpeg", "-v", "error", "-y"]
    if trim_head: args += ["-ss", "%g" % trim_head]
    args += ["-i", src]
    if trim_tail: args += ["-t", "%g" % (dur - trim_head - trim_tail)]
    vf = []
    if setpts and setpts != 1.0: vf.append("setpts=%g*PTS" % setpts)
    if vf: args += ["-vf", ",".join(vf)]
    args += ["-an", "-c:v", "libx264", "-preset", "slow", "-crf", "18",
             "-pix_fmt", "yuv420p", "-movflags", "+faststart", out]
    sh(args)

def remux_audio(video, audio, out, afade_out):
    dur = probe(video)["dur"]
    af = "loudnorm=I=-14:TP=-1.5:LRA=11"
    if afade_out:
        af += ",afade=t=out:st=%.3f:d=%g" % (max(dur - afade_out, 0), afade_out)
    sh(["ffmpeg", "-v", "error", "-y", "-i", video, "-i", audio,
        "-map", "0:v", "-map", "1:a", "-af", af,
        "-c:v", "copy", "-c:a", "aac", "-b:a", "192k", "-shortest", out])

def seam_report(master, frames_dir):
    meta = master + ".seams.json"
    if not os.path.exists(meta):
        sys.exit("no %s, assemble with this script first" % meta)
    seams = json.load(open(meta))["seams"]
    os.makedirs(frames_dir, exist_ok=True)
    for i, t in enumerate(seams):
        for tag, ts in (("before", t - 0.2), ("after", t + 0.2)):
            dst = os.path.join(frames_dir, "seam%02d_%s.png" % (i + 1, tag))
            sh(["ffmpeg", "-v", "error", "-y", "-ss", "%.3f" % max(ts, 0),
                "-i", master, "-frames:v", "1", dst])
    print("seam frames -> %s  (compare each before/after pair: near-identical or fix "
          "the chain)" % frames_dir)

def main():
    p = argparse.ArgumentParser()
    p.add_argument("clips", nargs="*")
    p.add_argument("--out")
    p.add_argument("--xfade", type=float, default=0.0)
    p.add_argument("--setpts", type=float, default=1.0)
    p.add_argument("--trim-head", type=float, default=0.0)
    p.add_argument("--trim-tail", type=float, default=0.0)
    p.add_argument("--remux")
    p.add_argument("--audio")
    p.add_argument("--afade-out", type=float, default=0.0)
    p.add_argument("--seam-report")
    p.add_argument("--frames-dir", default="qa_frames")
    a = p.parse_args()

    if a.seam_report:
        return seam_report(a.seam_report, a.frames_dir)
    if a.remux:
        if not (a.audio and a.out): sys.exit("--remux needs --audio and --out")
        return remux_audio(a.remux, a.audio, a.out, a.afade_out)
    if not (a.clips and a.out): sys.exit("assemble needs clips... and --out")

    ref = probe(a.clips[0])
    print("reference: %dx%d @ %.3f fps" % (ref["w"], ref["h"], ref["fps"]))
    norm_dir = os.path.join(os.path.dirname(os.path.abspath(a.out)) or ".", "_norm")
    normed = normalize(a.clips, norm_dir, ref["fps"], ref["w"], ref["h"])

    joined = a.out if (a.setpts == 1.0 and not a.trim_head and not a.trim_tail) \
        else a.out + ".join.mp4"
    if a.xfade > 0:
        xfade_concat(normed, joined, a.xfade, ref["fps"])
    else:
        hard_concat(normed, joined)
    if joined != a.out:
        post(joined, a.out, a.setpts, a.trim_head, a.trim_tail)
        os.remove(joined)

    durs = [probe(n)["dur"] for n in normed]
    seams, acc = [], 0.0
    for d in durs[:-1]:
        acc += d - (a.xfade if a.xfade > 0 else 0.0)
        seams.append(round(acc / a.setpts, 3))
    json.dump({"clips": a.clips, "durations": durs, "seams": seams},
              open(a.out + ".seams.json", "w"), indent=1)
    print("master: %s  (%.1fs, %d seams; QA: --seam-report %s)"
          % (a.out, probe(a.out)["dur"], len(seams), a.out))

if __name__ == "__main__":
    main()
