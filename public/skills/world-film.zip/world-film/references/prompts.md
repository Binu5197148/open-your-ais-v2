# Prompt templates & intake: world-film

Everything is fill-in-the-slots. Keep the **style preamble byte-for-byte identical**
across every prompt of a build, that identical text is what makes the world feel like
one place. (Science shared with the scroll-world skill; this file is self-contained.)

## Intake checklist (Step 1)

Collect and write down in `logs/run-manifest.md`:

- `SUBJECT`: the business + one-line pitch.
- `BRAND_NAME`: display name (optional for a film; used in briefs/end-card handoff).
- `PALETTE`: 4-6 named hexes. Pick ONE as the scene **background** (usually the
  lightest) and one **accent**.
- `TONE`: a word or two (cozy/premium, playful, industrial…).
- `STYLE`: art direction preamble (defaults below).
- `SCENES[]`: ordered; for each: `id`, `subject` (what's IN the scene), `focal`
  (what the camera seeks). Last scene is usually the hero product / payoff shot.
- `ARCH`: A (continuous forward take, default) | B (dive + aerial connectors,
  miniature worlds only).
- `FORMATS`: 16:9 | 9:16 | both (both ≈ 2× video credits, stated to the user).
- `DURATION`: target seconds → N from the SKILL Step 1.5 table.
- `AUDIO`: silent | music | vo | music+vo (ducked). VO house default: ElevenLabs
  voz BR, roteiro nascido em PT-BR.
- `VIDEO_TIER`: draft (`seedance_2_0_mini`) | standard (`seedance_2_0`, default) |
  alternate (`kling3_0`). Chosen by calibrated cost BEFORE rendering.
- `STILLS_SOURCE`: higgsfield (`gpt_image_2`, credits) | codex (`image_gen`,
  subscription-billed; offer only when the Codex CLI is present). One source for ALL
  stills of a build.

## Style preamble (default: clay diorama)

Reuse verbatim in every prompt. Swap the bracketed bits for the brand's palette/bg.

```
Isometric low-poly 3D diorama floating as a small rounded island on a plain solid
[BG_HEX] background with a soft contact shadow beneath it. Soft matte clay 3D render,
rounded toy-model shapes, gentle warm studio lighting, soft long shadows, tilt-shift
miniature look. Cohesive color palette of [PALETTE]. Highly detailed, centered
composition, absolutely no text, no letters, no numbers, no logos.
```

Alternate directions (swap the first two sentences, keep the palette/no-text tail):

- **Flat papercraft:** "Isometric layered paper-craft diorama, matte cardstock, clean
  die-cut edges, subtle drop shadows between layers."
- **Glossy toy:** "Isometric glossy vinyl-toy diorama, smooth plastic shading, soft rim
  light, collectible figurine look."
- **Claymation:** "Isometric stop-motion clay set, visible thumbprints, handmade
  plasticine texture, soft studio softbox light."
- **Neon night:** "Isometric miniature at night, warm interior glow and neon signage,
  moody rim light, wet reflective ground."
- **Photoreal architectural** (real estate, hospitality, premium/luxury):
  "Ultra-photorealistic architectural photography of a single cohesive [subject],
  cinematic wide-angle, warm golden-hour light, natural materials, restrained designer
  furnishings, a breathtaking view, editorial magazine quality (Architectural Digest),
  shallow depth of field, no people." For photoreal, drop the floating-island framing,
  scenes are full-bleed, the camera glides *through doorways/glass* rather than opening
  a roof, and cohesion comes entirely from the identical preamble (do NOT pass an
  `--image` reference, it clones the same room). Interiors trip Seedance's NSFW filter
  often; see SKILL Gotchas.

## Scene still prompt (Step 2: the storyboard)

```
[STYLE PREAMBLE]
Subject: [SCENE.subject, the building/space, a few characters doing the work, the
props that signal this stage of the business].
```

Tips:
- Name concrete props (they anchor the scene): tanks, cauldrons, conveyor, crates,
  awning, string lights, benches, scooters, map pins.
- Final "hero product" scene: drop the diorama-island framing; prompt a single
  oversized product centerpiece floating on the same background with a few small
  orbiting props.
- **Compose for the centre**: focal subject horizontally centred with headroom. The
  16:9 film keeps everything, but a centred still opens cleanly in the portrait chain
  and keeps the camera's target where it actually flies.
- Aspect `3:2`, `--resolution 2k --quality high`.

## Leg prompt: architecture A, continuous forward take

`--start-image = previous leg's ACTUAL last frame` (leg 0: the first scene's still).
**No `--end-image`.** The bolded clauses are the motion-handoff contract, keep them
verbatim; the mid-leg move is where the expression goes.

```
Single continuous cinematic camera move, no cuts. **Continue the same slow, steady
forward glide.** [MID-LEG MOVE, optional, from the library below.] The camera moves
into [SCENE i] toward [FOCAL POINT]. **In the final second, settle back into a slow,
steady forward glide toward [the doorway / opening / direction of the next scene].**
[STYLE tail + PALETTE]. Smooth, graceful, slow motion, subtle parallax. No text, no captions.
```

### Mid-leg move library (pick by concept; omit for a plain glide)

Reversals are safe *inside* a leg (one continuous render), only a seam may never
reverse.

- **Half-orbit** (product, luxury): "sweeping in a slow half-orbit around [the hero
  object], keeping it centered, then continuing past it"
- **Crane-up reveal** (scale, atriums, campuses): "rising smoothly as the full scale of
  [the space] reveals below"
- **Low lateral track** (production lines, counters, shelves): "tracking low and level
  alongside [the line], foreground objects sliding past in parallax"
- **Push-in + ease back** (craft, detail): "pushing in close to [the craft moment]
  until it nearly fills the frame, then easing gently back out"
- **Rise-and-swoop** (travel, outdoors): "climbing in a gentle arc over [the terrain],
  then swooping down toward [the next focal point]"

After rendering each leg, **check its last frame** before generating the next: it must
read as a frame from a calm forward glide (no sideways motion blur, no half-finished
orbit). If it doesn't, re-roll this leg, a bad handoff frame poisons every leg after it.

## Dive-in clip prompt (architecture B)

`--start-image = the scene still`.

```
Single continuous cinematic camera move, no cuts. Begin high and far, looking down at
the whole [SCENE.subject] from outside like a tiny model. The camera slowly glides
forward and descends toward it, sweeping in toward [FOCAL POINT], as if flying inside.
As the camera pushes in, the roof and upper structure gently lift and open away to
reveal the warm interior. [STYLE tail + PALETTE]. Smooth, graceful, slow motion,
subtle parallax. No text, no captions.
```

For scenes with no building to open (a field, a plaza, a road), replace the roof clause
with "the camera flies low across [the scene] toward [focal point]."

## Connector clip prompt (architecture B)

`--start-image = clip_i LAST frame` (extracted), `--end-image = clip_{i+1} FIRST frame`
(extracted). Both from the RENDERED videos, never the stills.

```
Single continuous cinematic camera move, no cuts. The camera smoothly pulls up and back
out of [SCENE i], rising into the sky, then glides forward across the connected
miniature world and arrives above [SCENE i+1], beginning to descend toward it. One
connected miniature clay world, seamless flowing aerial transition. [STYLE tail +
PALETTE]. Smooth graceful slow motion. No text, no captions.
```

Last connector into a hero-product finale: "…glides forward and the world dissolves
toward a single giant [PRODUCT] floating in soft [BG] space, arriving in front of it."

## Portrait clause (9:16 native chain)

Prepend to any leg/dive/connector prompt of the portrait chain (start images are the
portrait canvases / portrait renders, see pipeline §9):

```
Vertical portrait composition, the scene centered with generous [BG colour] space above
and below.
```

## Model params (both architectures)

- seedance (`seedance_2_0` / `seedance_2_0_mini`):
  `--mode std --resolution 1080p|720p --aspect_ratio 16:9|9:16 --duration 8` (legs/
  dives) or `5` (connectors). No audio flag ever (`--generate-audio` errors).
- kling3_0: `--mode std --sound off --aspect_ratio 16:9|9:16 --duration 10` (legs/
  dives) or `5` (connectors). NO `--resolution` param; 720p native on std, encode what
  ffprobe reports, never upscale.
