# Pipeline: copy-paste scripts (bash 3.2 safe): world-film

Every array-driven step runs in a `#!/bin/bash` script via `bash script.sh` (never
inline in zsh, 1-indexed arrays grab wrong frames). Higgsfield calls take minutes:
launch scripts **detached/backgrounded** and poll the log. On Windows: run under WSL
(`assemble.py` + ffmpeg also work natively).

## 0. Setup

```bash
RUN="$PWD/human-output/world-film/<run_slug>"     # the per-run folder (house rule)
mkdir -p "$RUN/prompts" "$RUN/src" "$RUN/frames" "$RUN/film" "$RUN/logs"
NAMES="farm kitchen shop delivery finale"          # ordered scene ids, last = hero/payoff

# Chain video model: ONE for every chained clip. Must accept --start-image
# (and --end-image for arch B connectors). Verify: higgsfield model get <model>
VMODEL=seedance_2_0
case "$VMODEL" in
  kling3_0)          VOPTS="--mode std --sound off";        LEG_DUR=10; CONN_DUR=5 ;;  # no --resolution on Kling
  seedance_2_0_mini) VOPTS="--mode std --resolution 720p";  LEG_DUR=8;  CONN_DUR=5 ;;  # frame-locked previz tier
  *)                 VOPTS="--mode std --resolution 1080p"; LEG_DUR=8;  CONN_DUR=5 ;;  # seedance_2_0 default
esac
AR=16:9   # or 9:16 for the portrait chain (§9)
```

## 1. Scene stills: the storyboard (Step 2)

One prompt file per scene at `$RUN/prompts/still_<name>.txt` (prompts.md), then:

```bash
gen_still() { # name
  higgsfield generate create gpt_image_2 --prompt "$(cat "$RUN/prompts/still_$1.txt")" \
    --aspect_ratio 3:2 --resolution 2k --quality high --wait --wait-timeout 15m --json \
    > "$RUN/logs/still_$1.json" 2> "$RUN/logs/still_$1.err"
  url=$(jq -r '.[0].result_url // empty' "$RUN/logs/still_$1.json")
  [ -n "$url" ] && curl -fsSL "$url" -o "$RUN/src/still_$1.png" && echo "still $1 ok" || echo "still $1 FAIL"
}
for n in $NAMES; do gen_still "$n" & done ; wait
```

Codex variant (STILLS_SOURCE=codex, subscription-billed, zero credits, ~1-3 min each,
parallelize in small batches):

```bash
gen_still_codex() { # name
  codex exec -C "$RUN/src" -s workspace-write --skip-git-repo-check \
    'Use the image generation tool ($imagegen) to generate: '"$(cat "$RUN/prompts/still_$1.txt")"' Wide 3:2 landscape, high resolution. Save it as ./still_'"$1"'.png. Do not do anything else.' \
    > "$RUN/logs/still_$1.codex.log" 2>&1
  [ -f "$RUN/src/still_$1.png" ] && echo "still $1 ok (codex)" || echo "still $1 FAIL"
}
```

**STORYBOARD GATE:** show every still to the user in journey order; re-roll off-style
scenes (`--image "$RUN/src/still_<good>.png"` locks style). **No video generation until
the user approves the full storyboard.**

## 2a. Architecture A: the legs (sequential, N videos)

Prompt files at `$RUN/prompts/leg_<name>.txt`. Leg 0 starts from the first still; every
next leg starts from the previous leg's ACTUAL last frame. Strictly sequential, and
eyeball each `last_leg_*.png` before letting the next leg render (a bad handoff frame
poisons the rest of the chain).

```bash
#!/bin/bash
gen_leg() { # name startImg
  higgsfield generate create "$VMODEL" --prompt "$(cat "$RUN/prompts/leg_$1.txt")" \
    --start-image "$2" \
    $VOPTS --aspect_ratio "$AR" --duration "$LEG_DUR" \
    --wait --wait-timeout 20m --json > "$RUN/logs/leg_$1.json" 2> "$RUN/logs/leg_$1.err"
  url=$(jq -r '.[0].result_url // empty' "$RUN/logs/leg_$1.json")
  [ -n "$url" ] && curl -fsSL "$url" -o "$RUN/src/leg_$1.mp4" && echo "leg $1 ok" || { echo "leg $1 FAIL"; return 1; }
}
set -- $NAMES
start=""; first=1
for n in "$@"; do
  if [ $first -eq 1 ]; then start="$RUN/src/still_$n.png"; first=0; fi
  gen_leg "$n" "$start" || exit 1
  ffmpeg -v error -y -sseof -0.15 -i "$RUN/src/leg_$n.mp4" -frames:v 1 -q:v 2 "$RUN/frames/last_leg_$n.png"
  start="$RUN/frames/last_leg_$n.png"      # next leg continues from the real last frame
done
```

Chain order for assembly = the legs in scene order. Skip §2b-§4.

## 2b. Architecture B: dive-in clips (parallel, N videos)

Prompt files at `$RUN/prompts/dive_<name>.txt`. Start image = the scene still.

```bash
gen_dive() { # name
  higgsfield generate create "$VMODEL" --prompt "$(cat "$RUN/prompts/dive_$1.txt")" \
    --start-image "$RUN/src/still_$1.png" \
    $VOPTS --aspect_ratio "$AR" --duration "$LEG_DUR" \
    --wait --wait-timeout 20m --json > "$RUN/logs/dive_$1.json" 2> "$RUN/logs/dive_$1.err"
  url=$(jq -r '.[0].result_url // empty' "$RUN/logs/dive_$1.json")
  [ -n "$url" ] && curl -fsSL "$url" -o "$RUN/src/dive_$1.mp4" && echo "dive $1 ok" || echo "dive $1 FAIL"
}
for n in $NAMES; do gen_dive "$n" & done ; wait
```

Re-roll individual failures only (503 / credit races are transient): `gen_dive shop`.

## 3. Boundary frames: the seam handoff (arch B)

Connector endpoints come from the **rendered videos**, never the stills:

```bash
#!/bin/bash
for n in $NAMES; do
  ffmpeg -v error -y -ss 0          -i "$RUN/src/dive_$n.mp4" -frames:v 1 -q:v 2 "$RUN/frames/first_$n.png"
  ffmpeg -v error -y -sseof -0.15   -i "$RUN/src/dive_$n.mp4" -frames:v 1 -q:v 2 "$RUN/frames/last_$n.png"
done
```

## 4. Connectors (arch B, N-1 videos: need --end-image)

Prompt files at `$RUN/prompts/conn_<i>.txt` (i = 1..N-1):

```bash
#!/bin/bash
gen_conn() { # i startPng endPng
  higgsfield generate create "$VMODEL" --prompt "$(cat "$RUN/prompts/conn_$1.txt")" \
    --start-image "$2" --end-image "$3" \
    $VOPTS --aspect_ratio "$AR" --duration "$CONN_DUR" \
    --wait --wait-timeout 20m --json > "$RUN/logs/conn_$1.json" 2> "$RUN/logs/conn_$1.err"
  url=$(jq -r '.[0].result_url // empty' "$RUN/logs/conn_$1.json")
  [ -n "$url" ] && curl -fsSL "$url" -o "$RUN/src/conn_$1.mp4" && echo "conn $1 ok" || echo "conn $1 FAIL"
}
set -- $NAMES ; i=0 ; prev=""
for n in "$@"; do
  if [ -n "$prev" ]; then i=$((i+1)); gen_conn "$i" "$RUN/frames/last_$prev.png" "$RUN/frames/first_$n.png" & fi
  prev="$n"
done ; wait
```

Chain order for assembly = `dive_1 conn_1 dive_2 conn_2 … dive_N`.

## 5. Assemble the master (normalize → concat → xfade fallback)

`assemble.py` does probe + normalize + join in one call. Chain order matters.

```bash
# Arch A:
python3 assemble.py --out "$RUN/film/master.mp4" $(for n in $NAMES; do echo "$RUN/src/leg_$n.mp4"; done)

# Arch B (interleave dives and connectors):
python3 assemble.py --out "$RUN/film/master.mp4" \
  "$RUN/src/dive_farm.mp4" "$RUN/src/conn_1.mp4" "$RUN/src/dive_kitchen.mp4" ...
```

- Default join is a **hard concat** of normalized clips (frame-identical seams = an
  invisible cut). The concat list is written with **relative paths** and run from
  inside the normalized folder (absolute paths in concat lists are a known foot-gun).
- If QA (§7) shows a micro-pop at a seam, re-run with `--xfade 0.2` (chained ffmpeg
  `xfade` with computed offsets). A crossfade hides render drift, never a content jump.
- Global pacing: `--setpts 0.9` tightens the whole film uniformly (mid-chain trims are
  forbidden, the matched frames ARE the seams; head/tail trims via `--trim-head/-tail`).

## 6. Audio

One continuous bed/VO over the whole film (never per-clip audio):

```bash
# Music bed only (fade out at the tail):
python3 assemble.py --remux "$RUN/film/master.mp4" --audio trilha.mp3 --afade-out 1.5 \
  --out "$RUN/film/master_scored.mp4"

# Voiceover + music, VO ducks the bed, then social loudness:
ffmpeg -y -i "$RUN/film/master.mp4" -i vo.wav -i trilha.mp3 -filter_complex \
 "[2:a][1:a]sidechaincompress=threshold=0.03:ratio=8:attack=5:release=400[bed];\
  [bed][1:a]amix=inputs=2:duration=first:dropout_transition=0,loudnorm=I=-14:TP=-1.5:LRA=11[a]" \
 -map 0:v -map "[a]" -c:v copy -shortest "$RUN/film/master_scored.mp4"
```

Locução: roteiro nasce em PT-BR (regra da casa), voz ElevenLabs BR do stack do usuário;
time the script against the scene map (clip durations are known). Legendas/lettering/
end-card: hand off to Hyperframes (`novelty` skill), this pipeline ships the clean film.

## 7. QA the seams + duration (don't skip)

```bash
# Seam timestamps = cumulative durations; extract ±0.2s around each and compare:
python3 assemble.py --seam-report "$RUN/film/master.mp4" --frames-dir "$RUN/frames/qa"
# Duration (MEDIR, não estimar: regra da casa):
ffprobe -v error -show_entries format=duration -of default=nw=1:nk=1 "$RUN/film/master_scored.mp4"
```

Watch the film once start-to-finish: it must read as ONE take. Any velocity flip at a
seam = a bad handoff frame → re-roll that leg/connector and re-assemble.

## 8. Delivery encodes

```bash
enc_deliver() { # in out scale
  ffmpeg -v error -y -i "$1" -vf "scale=$3,unsharp=5:5:0.6:5:5:0.0" \
    -c:v libx264 -preset slow -crf 18 -pix_fmt yuv420p -movflags +faststart \
    -c:a aac -b:a 192k "$2"
}
enc_deliver "$RUN/film/master_scored.mp4" "$RUN/film/final_16x9_1080.mp4" "1920:1080"
# The 9:16 delivery comes from the NATIVE portrait chain (§9), not a crop.
```

Never upscale past the render's native resolution (kling std = 720p → deliver 720p wide
or re-render the tier). A center-crop 9:16 from the 16:9 master is a stopgap the user
must explicitly approve.

## 9. Native 9:16 portrait chain (FORMATS includes 9:16)

A parallel chain composed for portrait, same seam laws, frame-locked against its OWN
renders (never mixed with landscape frames). Budget it at the interview (~doubles the
video gens; NSFW re-rolls happen in portrait too).

1. **Portrait start canvases** (don't hand the model a 3:2 still and hope): composite
   each still onto a 1080×1920 canvas in the bg colour, scene at ~94% width, visual
   centre at ~45% height:

   ```bash
   python3 - "$RUN/src/still_farm.png" "$RUN/src/still_farm_p.png" "#F5EDE0" <<'EOF'
   import sys; from PIL import Image
   src, dst, bg = sys.argv[1], sys.argv[2], sys.argv[3]
   W,H = 1080,1920
   im = Image.open(src).convert("RGBA")
   w = int(W*0.94); h = int(w*im.height/im.width)
   im = im.resize((w,h), Image.LANCZOS)
   cv = Image.new("RGBA",(W,H), bg)
   cv.paste(im, ((W-w)//2, int(H*0.45 - h/2)), im)
   cv.convert("RGB").save(dst, quality=95)
   EOF
   ```

2. **Legs/dives**: same prompt templates with the portrait clause up front
   (prompts.md), `--aspect_ratio 9:16`, same model/params, start = the portrait canvas
   (leg 0) then the portrait chain's own last frames. Review last frames as ever.
3. **Connectors (B)**: first/last frames extracted **from the 9:16 renders**.
4. **Assemble + score + deliver**: §5-§8 with the portrait clips →
   `final_9x16_1080x1920.mp4`.

## Notes

- `.[0].result_url` is the field on `--wait --json` output; `curl` it down.
- **NSFW fallback**: a clip that keeps flagging on seedance after re-rolls + prompt
  scrubbing → regenerate JUST that clip on `kling3_0` with the SAME frames
  (`VMODEL=kling3_0; VOPTS="--mode std --sound off"`), then restore the chain model.
- **Previz on the cheap**: run the whole chain once on `seedance_2_0_mini` (~¼ cost,
  frame-locking intact) to validate journey + seams, then re-render final legs on the
  full model, the previz translates directly because it's already seamless.
- Batch stalls → check `higgsfield workspace list` (credits) and `$RUN/logs/*.err`.
- Concurrency: ~5-6 gens at once; more triggers transient credit-race errors.
