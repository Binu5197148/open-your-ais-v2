# world-film

Same continuous world-flight generation as scroll-world, but the deliverable is one MP4 assembled with ffmpeg instead of a website.

From the working skill library of Ulisses Balbino. Released at
https://openyourais.com/skills/

Instructions are written in: English

## Install

```
# Claude Code, available in every project
unzip world-film.zip -d ~/.claude/skills/

# or scoped to one repo
unzip world-film.zip -d .claude/skills/
```

You should end up with `world-film/SKILL.md`. Start a new session so the
skill is picked up.

## Needs

Higgsfield CLI, authenticated. ffmpeg and ffprobe. Python 3 for the assembler.

## What changed before release

Nothing. The files went out exactly as they run here.

---

Shared as is, no warranty. It names third party tools and models, and
those age fast. Check what a job costs before you let an agent spend.
