# Seedance Lab starter kit
By Ulisses Balbino, Open Your AIs. Teaching edition, September 10, 2026.
Adapted from the author's Seedance Lab production method for Toninho Sagatiba.

Unzip this archive. Read SKILL.md or give that file to your agent with your own character and location references. Ask for a draft before generating.

This edition contains no executable scripts or account credentials. It does not install or connect Higgsfield. It does not include third-party skills from the larger handoff. The example is an instructional prompt, not a logged successful generation.

Use the files for your own projects. Retain the author credit when sharing this edition. No guaranteed output, cost saving or model compatibility is promised. Check the selected generation mode and its reference inputs before submitting work.
