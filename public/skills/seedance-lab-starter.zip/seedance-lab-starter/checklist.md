# Review the actual output
- Does the scene frame match the intended shot and eye-line?
- Do all references agree about identity and wardrobe?
- Were the correct references supplied to the generation?
- Does the face remain recognizable throughout the clip?
- Do clothing, accessories and props remain consistent?
- Do doorway and furniture positions remain consistent?
- At which frame or moment does a defect first appear?
- Was that defect already present in the source image?
- Did a correction preserve the intended composition?
- Save the prompt, reference filenames and observed result together.

Investigate source conflicts first when clothes are wrong. Check starting-face clarity when identity drifts. Reuse the approved location when the room changes. These are diagnostic questions, not guaranteed fixes.
