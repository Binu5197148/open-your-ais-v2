---
name: seedance-lab-starter
description: Prepare references and a reviewed prompt for a simple character-continuity exercise inspired by Toninho Sagatiba.
---
# Seedance Lab starter

Start with the user's directing intention and their actual reference files.
1. Identify the character, wardrobe, room, eye-line and intended action. Ask only about missing choices that affect this shot.
2. Inspect references for conflicts. Explain which image governs which feature. Do not assume a file is attached to a generation because it appears in the conversation.
3. Prepare a scene-frame proposal. Preserve the intended composition when correcting identity.
4. Have the user review the actual frame before animation.
5. Draft a prompt using prompt.txt. Confirm current model/mode capabilities and supported reference inputs through the user's available tools. Never invent commands or attachment syntax.
6. Show duration and cost estimate when available. Obtain the user's approval before spending credits; existing explicit authorization still applies within its scope.
7. Review the actual result against checklist.md. Treat identity and continuity instructions as targets, not guarantees.
8. Describe observed defects specifically. Change the relevant source or instruction and compare again within the user's approved budget.

Do not invent test results. Do not execute generations just because this skill is being read. This starter covers a silent shot, not a lip-sync pipeline.
