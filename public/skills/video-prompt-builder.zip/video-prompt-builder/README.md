# video-prompt-builder

Turns a creative brief into a shot-by-shot video prompt for Seedance 2.0, in four mandatory sections covering camera, effects, transitions and the energy arc.

From the working skill library of Ulisses Balbino. Released at
https://openyourais.com/skills/

Instructions are written in: English

## Install

```
# Claude Code, available in every project
unzip video-prompt-builder.zip -d ~/.claude/skills/

# or scoped to one repo
unzip video-prompt-builder.zip -d .claude/skills/
```

You should end up with `video-prompt-builder/SKILL.md`. Start a new session so the
skill is picked up.

## Needs

Nothing. The output is a prompt.

## What changed before release

Nothing.

---

Shared as is, no warranty. It names third party tools and models, and
those age fast. Check what a job costs before you let an agent spend.
